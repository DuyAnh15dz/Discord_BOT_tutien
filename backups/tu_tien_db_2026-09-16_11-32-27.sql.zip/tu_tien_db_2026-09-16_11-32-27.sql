-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: tu_tien_db
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `canh_gioi`
--

DROP TABLE IF EXISTS `canh_gioi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `canh_gioi` (
  `id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `ten` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cap_bac` tinyint unsigned NOT NULL,
  `so_tang` tinyint unsigned NOT NULL DEFAULT '9',
  `exp_tang_1` bigint unsigned NOT NULL DEFAULT '100' COMMENT 'Exp cần cho tầng 1 → 2',
  `he_so_tang` decimal(4,3) NOT NULL DEFAULT '1.100' COMMENT 'Hệ số nhân exp mỗi tầng (1.1 = +10%)',
  `he_so_dot_pha` decimal(4,2) NOT NULL DEFAULT '9.00' COMMENT 'Hệ số nhân exp khi đột phá cảnh giới (×9)',
  `ti_le_dot_pha_co_ban` decimal(5,2) NOT NULL DEFAULT '50.00' COMMENT 'Tỉ lệ đột phá cơ bản (%)',
  `ti_le_dot_pha_toi_da` decimal(5,2) NOT NULL DEFAULT '95.00' COMMENT 'Tỉ lệ đột phá tối đa (%)',
  `he_so_suc_manh` decimal(6,2) NOT NULL DEFAULT '1.00' COMMENT 'Hệ số nhân stat theo cảnh giới',
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_canh_gioi_ten` (`ten`),
  UNIQUE KEY `uk_canh_gioi_cap_bac` (`cap_bac`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Cảnh giới tu luyện. cap_bac: 1=Luyện Khí → 10=Tiên Nhân';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `canh_gioi`
--

LOCK TABLES `canh_gioi` WRITE;
/*!40000 ALTER TABLE `canh_gioi` DISABLE KEYS */;
INSERT INTO `canh_gioi` VALUES (1,'Luyện Khí',1,9,100,1.100,9.00,80.00,95.00,1.00,'Cảnh giới nhập môn, hấp thu linh khí trời đất'),(2,'Trúc Cơ',2,9,500,1.100,9.00,60.00,95.00,1.50,'Xây dựng nền tảng tu luyện, đặt cơ sở đạo cơ'),(3,'Kim Đan',3,9,2000,1.100,9.00,40.00,85.00,2.00,'Kết thành kim đan trong đan điền, thọ nguyên tăng'),(4,'Nguyên Anh',4,9,8000,1.100,9.00,25.00,70.00,3.00,'Nguyên anh xuất khiếu, thần thông quảng đại'),(5,'Hóa Thần',5,9,30000,1.100,9.00,15.00,70.00,5.00,'Thần thức hóa hình, uy lực vô biên'),(6,'Luyện Hư',6,9,100000,1.100,9.00,10.00,70.00,8.00,'Luyện hư thành thực, cảm ngộ không gian'),(7,'Hợp Thể',7,9,350000,1.100,9.00,7.00,70.00,12.00,'Hợp nhất với thiên địa, gần với đại đạo'),(8,'Đại Thừa',8,9,1200000,1.100,9.00,5.00,60.00,20.00,'Đại thừa chi cảnh, sắp sửa phi thăng'),(9,'Độ Kiếp',9,9,5000000,1.100,9.00,3.00,50.00,35.00,'Độ thiên kiếp, chuẩn bị thành tiên'),(10,'Tiên Nhân',10,9,20000000,1.100,9.00,1.00,20.00,60.00,'Phi thăng thành tiên, vĩnh hằng bất diệt');
/*!40000 ALTER TABLE `canh_gioi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `he_thong_config`
--

DROP TABLE IF EXISTS `he_thong_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `he_thong_config` (
  `key_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` json NOT NULL,
  `mo_ta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Config động, không hardcode vào code bot';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `he_thong_config`
--

LOCK TABLES `he_thong_config` WRITE;
/*!40000 ALTER TABLE `he_thong_config` DISABLE KEYS */;
INSERT INTO `he_thong_config` VALUES ('bonus_ti_le_roi_do_max','500','Bonus tối đa +500%','2026-09-12 17:54:54'),('bonus_ti_le_roi_linh_thach_max','500','Bonus tối đa +500% cho rớt linh thạch','2026-09-12 17:54:54'),('bxh_thuong_exp_max','1500','Thưởng exp tối đa','2026-09-14 22:12:22'),('bxh_thuong_exp_min','1000','Thưởng exp tối thiểu','2026-09-14 22:12:22'),('bxh_thuong_hang1_he_so','3.0','Hệ số nhân thưởng hạng 1','2026-09-14 22:12:22'),('bxh_thuong_hang2_he_so','2.0','Hệ số nhân thưởng hạng 2','2026-09-14 22:12:22'),('bxh_thuong_hang3_he_so','1.5','Hệ số nhân thưởng hạng 3','2026-09-14 22:12:22'),('bxh_thuong_linh_thach_max','5000','Thưởng linh thạch tối đa','2026-09-14 22:12:22'),('bxh_thuong_linh_thach_min','2000','Thưởng linh thạch tối thiểu (hạng 4-10)','2026-09-14 22:12:22'),('bxh_thuong_tu_vi_max','1500','Thưởng tu vi tối đa','2026-09-14 22:12:22'),('bxh_thuong_tu_vi_min','1000','Thưởng tu vi tối thiểu','2026-09-14 22:12:22'),('chinh_xac_toi_da','1.0','Chính xác tối đa 100%','2026-09-12 17:54:54'),('dao_cu_tang_tinh_khiet_pct','{\"Ha\": 30, \"Cuc\": 10, \"Tien\": 5, \"Trung\": 25, \"Thuong\": 20}','Tỉ lệ tăng độ tinh khiết của đạo cụ, theo [phẩm cấp đạo cụ][phẩm cấp linh căn]','2026-09-13 21:49:50'),('do_kiep_toi_da','0.95','Tỉ lệ độ kiếp thành công tối đa 95%','2026-09-12 17:54:54'),('doi_ten_price','5000','Giá đổi tên nhân vật','2026-09-12 17:54:54'),('dotpha_bonus_dao_cu_max','50','Bonus tối đa từ đạo cụ (%)','2026-09-13 15:41:14'),('dotpha_cooldown_sec','1800','Cooldown /dotpha (giây)','2026-09-12 17:54:54'),('dotpha_cooldown_that_bai','{\"1\": 3600, \"2\": 7200, \"3\": 14400, \"4\": 28800, \"5\": 57600, \"6\": 64800, \"7\": 72000, \"8\": 79200, \"9\": 86400, \"10\": 108000}','Cooldown khi độ kiếp thất bại (giây). Cảnh giới 1 = 2h, 2 = 4h, 3 = 8h...','2026-09-13 16:30:46'),('drop_rate_boss_base','0.15','Tỉ lệ rớt đồ khi đánh boss','2026-09-12 17:54:54'),('drop_rate_max','1.0','Tỉ lệ tối đa 100%','2026-09-12 17:54:54'),('drop_rate_mob_base','0.05','Tỉ lệ rớt đồ khi đánh quái thường','2026-09-12 17:54:54'),('enable_cho_giao_dich','false','Bật chợ giao dịch?','2026-09-12 17:54:54'),('enable_pvp','true','Bật PvP?','2026-09-12 17:54:54'),('exp_bonus_event','2.0','Hệ số exp khi có event','2026-09-12 17:54:54'),('exp_rate','1.0','Hệ số nhân exp','2026-09-12 17:54:54'),('giam_cooldown','0.0','Giảm hồi chiêu theo %','2026-09-12 17:54:54'),('giam_cooldown_toi_da','0.45','Giảm hồi chiêu theo %','2026-09-12 17:54:54'),('giam_sat_thuong_toi_da','0.9','Giảm sát thương tối đa 90%','2026-09-12 17:54:54'),('hieu_ung_hoi_hp_toi_da','5.0','Tăng tối đa 500% cho lượng hồi phục','2026-09-12 17:54:54'),('hoi_mp_toi_da','0.5','Hồi MP tối đa 50%','2026-09-12 17:54:54'),('hp_regen_delay_sec','5','Delay trước khi bắt đầu hồi HP (giây)','2026-09-13 17:08:59'),('hp_regen_pct_per_sec','1.0','HP hồi mỗi giây ngoài combat (% HP max)','2026-09-13 17:08:59'),('hut_mau_toi_da','0.5','Hút máu tối đa 50%','2026-09-12 17:54:54'),('khang_chi_mang_toi_da','0.9','Kháng chí mạng tối đa 90%','2026-09-12 17:54:54'),('khang_toi_da','0.9','Kháng tối đa 90%','2026-09-12 17:54:54'),('kich_hoat_hoi_hp_toi_da','1.0','Xác suất  80% kích hoạt hồi HP tối đa','2026-09-12 17:54:54'),('lichluyen_cooldown_sec','180','Cooldown /lichluyen (giây)','2026-09-13 19:28:30'),('lichluyen_dan_phuong_ti_le','{\"Bao\": 15, \"Linh\": 30, \"Pham\": 50, \"Than\": 1, \"Tien\": 4}','Tỉ lệ rơi đan phương theo phẩm cấp (%)','2026-09-13 17:22:34'),('lichluyen_khoang_thach_so_luong','{\"max\": 5, \"min\": 1}','Số lượng khoáng thạch nhận mỗi lần lịch luyện (min-max)','2026-09-13 22:13:59'),('lichluyen_khoang_thach_ti_le','{\"Bao\": 15, \"Linh\": 30, \"Pham\": 50, \"Than\": 1, \"Tien\": 4}','Tỉ lệ rơi khoáng thạch theo phẩm cấp (%)','2026-09-13 22:13:59'),('lichluyen_linh_thao_so_luong','{\"max\": 2, \"min\": 1}','Số lượng linh thảo nhận mỗi lần lịch luyện (min-max)','2026-09-13 17:34:26'),('lichluyen_linh_thao_ti_le','{\"Bao\": 15, \"Linh\": 30, \"Pham\": 50, \"Than\": 1, \"Tien\": 4}','Tỉ lệ rơi linh thảo theo phẩm cấp (%)','2026-09-13 17:22:34'),('lichluyen_so_su_kien','3','Số sự kiện random mỗi lần lịch luyện','2026-09-13 17:16:19'),('linh_can_cay_tinh_khiet_amount_max','0.2','Số độ tinh khiết tối đa mỗi lần tăng','2026-09-13 12:06:48'),('linh_can_cay_tinh_khiet_amount_min','0.05','Số độ tinh khiết tối thiểu mỗi lần tăng','2026-09-13 12:06:48'),('linh_can_cay_tinh_khiet_chance','0.02','Xác suất tăng độ tinh khiết mỗi lần /tuluyen','2026-09-13 12:06:48'),('linh_can_dot_pha_bonus_that_bai','0.05','Bonus tỉ lệ mỗi lần thất bại (+5%)','2026-09-12 17:54:54'),('linh_can_dot_pha_mat_tinh_khiet_max','35','Mất tinh khiết tối đa khi fail','2026-09-15 08:09:52'),('linh_can_dot_pha_mat_tinh_khiet_min','15','Mất tinh khiết tối thiểu khi fail','2026-09-15 08:09:52'),('linh_can_dot_pha_max_lan_dung_dao_cu','2','Số lần tối đa dùng đạo cụ tăng tỉ lệ','2026-09-15 08:09:52'),('linh_can_dot_pha_ti_le_co_ban','25.0','Tỉ lệ đột phá cơ bản (50%)','2026-09-15 08:09:52'),('linh_can_dot_pha_ti_le_max','0.95','Tỉ lệ đột phá tối đa (95%)','2026-09-12 17:54:54'),('linh_can_ky_ngo_tinh_khiet_max','20','Độ tinh khiết tối đa từ kỳ ngộ','2026-09-12 17:54:54'),('linh_can_ky_ngo_tinh_khiet_min','5','Độ tinh khiết tối thiểu từ kỳ ngộ','2026-09-12 17:54:54'),('linh_can_roll_nhom_he','{\"DiHe\": 15, \"NguHanh\": 85}','Tỉ lệ roll nhóm hệ. Tổng = 100','2026-09-13 09:19:29'),('linh_can_roll_pham_cap','{\"Ha\": 70, \"Cuc\": 4, \"Tien\": 1, \"Trung\": 15, \"Thuong\": 10}','Tỉ lệ roll phẩm cấp. Tổng = 100','2026-09-13 09:19:29'),('linh_can_roll_so_luong','{\"1\": 5, \"2\": 15, \"3\": 30, \"4\": 30, \"5\": 20}','Tỉ lệ roll số lượng linh căn. Tổng = 100','2026-09-13 19:36:25'),('linh_thach_rate','1.0','Hệ số linh thạch','2026-09-12 17:54:54'),('linh_thach_rate_mob_base','0.3','Tỉ lệ rớt linh thạch','2026-09-12 17:54:54'),('luyen_dan_so_vien_max','{\"1\": 9, \"2\": 7, \"3\": 5, \"4\": 3, \"5\": 3}','Số viên đan tối đa khi luyện thành công (theo cấp: 1=Phàm, 2=Linh, 3=Bảo, 4=Tiên, 5=Thần)','2026-09-12 17:54:54'),('luyendan_cooldown_sec','120','Cooldown /luyendan (giây)','2026-09-12 17:54:54'),('max_cong_phap_active','2','Số công pháp tu luyện song song','2026-09-12 17:54:54'),('max_linh_can_per_player','5','Số linh căn tối đa 1 player có','2026-09-12 17:54:54'),('max_players','10000','Số player tối đa','2026-09-12 17:54:54'),('mo_khoa_tui_price','10000','Giá mở rộng túi đồ','2026-09-12 17:54:54'),('ne_toi_da','0.75','Né tối đa 75%','2026-09-12 17:54:54'),('ngo_dao_toi_da','0.2','Tỉ lệ ngộ đạo tối đa 20%','2026-09-12 17:54:54'),('phan_tram_hoi_hp_toi_da','0.25','Hồi HP tối đa 25% HP_max/lượt','2026-09-12 17:54:54'),('sat_thuong_chi_mang_toi_da','5.0','Sát thương chí mạng tối đa 500%','2026-09-12 17:54:54'),('sat_thuong_toi_thieu','1','Sát thương tối thiểu','2026-09-12 17:54:54'),('server_maintenance','false','Bot đang bảo trì?','2026-09-12 17:54:54'),('so_hieu_ung_toi_da','5','Số hiệu ứng tối đa trên 1 player','2026-09-12 17:54:54'),('stat_tang_moi_tang_pct','5.0','Phần trăm tăng stat mỗi tầng (%)','2026-09-13 20:22:46'),('ti_le_gay_hieu_ung_toi_da','0.7','Tỉ lệ gây hiệu ứng tối đa 70%','2026-09-12 17:54:54'),('toc_do_tu_luyen_theo_linh_can','{\"1\": 3.0, \"2\": 2.5, \"3\": 2.0, \"4\": 1.5, \"5\": 1.0}','Hệ số nhân exp khi tu luyện dựa vào số linh căn. Càng ít càng mạnh.','2026-09-13 16:09:46'),('toc_do_tu_luyen_toi_da','10.0','Tốc độ tu luyện tối đa ×10','2026-09-12 17:54:54'),('tu_vi_rate','1.0','Hệ số tu vi','2026-09-12 17:54:54'),('tuluyen_cooldown_sec','60','Cooldown /tuluyen (giây)','2026-09-12 17:54:54'),('ty_gia_tien_ngoc_linh_thach','10000','1 tiên ngọc = ? linh thạch','2026-09-12 17:54:54'),('version','\"1.0.0\"','Phiên bản bot','2026-09-12 17:54:54'),('xuyen_giap_toi_da','0.9','xuyên giáp VL tối đa 90%','2026-09-12 17:54:54'),('xuyen_phep_toi_da','0.9','xuyên giáp phép tối đa 90%','2026-09-12 17:54:54');
/*!40000 ALTER TABLE `he_thong_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_bxh_thuong`
--

DROP TABLE IF EXISTS `log_bxh_thuong`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_bxh_thuong` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `loai_bxh` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hang` int unsigned NOT NULL,
  `linh_thach` bigint unsigned NOT NULL DEFAULT '0',
  `exp` bigint unsigned NOT NULL DEFAULT '0',
  `tu_vi` bigint unsigned NOT NULL DEFAULT '0',
  `dan_phuong_nhan` json DEFAULT NULL COMMENT 'Danh sách [dan_duoc_id, ...]',
  `dao_cu_nhan` smallint unsigned DEFAULT NULL COMMENT 'ID đạo cụ nhận được',
  `tuan` date NOT NULL COMMENT 'Ngày thứ 2 đầu tuần',
  `thoi_diem` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lbxh_player` (`player_id`,`tuan`),
  KEY `idx_lbxh_loai_tuan` (`loai_bxh`,`tuan`),
  CONSTRAINT `fk_lbxh_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Log trao thưởng BXH hàng tuần';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_bxh_thuong`
--

LOCK TABLES `log_bxh_thuong` WRITE;
/*!40000 ALTER TABLE `log_bxh_thuong` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_bxh_thuong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_daily`
--

DROP TABLE IF EXISTS `log_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_daily` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `ngay` date NOT NULL,
  `streak` int unsigned NOT NULL,
  `linh_thach_nhan` bigint unsigned NOT NULL,
  `thoi_diem` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_daily_player` (`player_id`,`thoi_diem`),
  CONSTRAINT `fk_ld_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_daily`
--

LOCK TABLES `log_daily` WRITE;
/*!40000 ALTER TABLE `log_daily` DISABLE KEYS */;
INSERT INTO `log_daily` VALUES (1,7,'2026-09-15',1,181,'2026-09-15 07:17:09');
/*!40000 ALTER TABLE `log_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dot_pha`
--

DROP TABLE IF EXISTS `log_dot_pha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_dot_pha` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `tu_canh_gioi_id` tinyint unsigned NOT NULL,
  `tu_tang` tinyint unsigned NOT NULL,
  `den_canh_gioi_id` tinyint unsigned DEFAULT NULL,
  `den_tang` tinyint unsigned DEFAULT NULL,
  `ti_le_cuoi` decimal(5,2) NOT NULL COMMENT 'Tỉ lệ đột phá cuối cùng sau khi cộng bonus',
  `ti_le_co_ban` decimal(5,2) NOT NULL COMMENT 'Tỉ lệ cơ bản của cảnh giới',
  `bonus_linh_can` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Bonus từ linh căn',
  `bonus_dan_duoc` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Bonus từ đan dược',
  `bonus_dao_cu` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Bonus từ đạo cụ đột phá (%)',
  `bonus_khac` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Bonus từ tâm cảnh, khí vận, thất bại liên tiếp...',
  `dao_cu_id` smallint unsigned DEFAULT NULL COMMENT 'Đạo cụ hỗ trợ đột phá (nếu có)',
  `thanh_cong` tinyint NOT NULL,
  `thoi_diem` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_dotpha` (`player_id`,`thoi_diem`),
  KEY `idx_log_dotpha_canh_gioi` (`tu_canh_gioi_id`,`thoi_diem`),
  KEY `idx_log_dotpha_thanh_cong` (`thanh_cong`,`thoi_diem`),
  KEY `fk_ldp_dao_cu` (`dao_cu_id`),
  CONSTRAINT `fk_ldp_dao_cu` FOREIGN KEY (`dao_cu_id`) REFERENCES `tmpl_dao_cu` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ldp_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ldp_thanh_cong` CHECK ((`thanh_cong` in (0,1))),
  CONSTRAINT `chk_ldp_ti_le` CHECK ((`ti_le_cuoi` between 0 and 100))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Log đột phá. Lưu chi tiết tỉ lệ để audit và balance.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dot_pha`
--

LOCK TABLES `log_dot_pha` WRITE;
/*!40000 ALTER TABLE `log_dot_pha` DISABLE KEYS */;
INSERT INTO `log_dot_pha` VALUES (2,7,1,9,2,1,80.00,80.00,0.00,0.00,0.00,0.00,NULL,1,'2026-09-14 08:08:05'),(3,7,2,9,3,1,60.00,60.00,0.00,0.00,0.00,0.00,NULL,1,'2026-09-14 08:50:25'),(4,7,3,9,NULL,NULL,44.00,40.00,4.00,0.00,0.00,0.00,NULL,0,'2026-09-15 10:26:54');
/*!40000 ALTER TABLE `log_dot_pha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_dot_pha_linh_can`
--

DROP TABLE IF EXISTS `log_dot_pha_linh_can`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_dot_pha_linh_can` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `linh_can_id_cu` smallint unsigned NOT NULL COMMENT 'Linh căn trước khi đột phá',
  `linh_can_id_moi` smallint unsigned NOT NULL COMMENT 'Linh căn sau khi đột phá (dù thành công hay không)',
  `dao_cu_id` smallint unsigned DEFAULT NULL COMMENT 'Đạo cụ đã dùng (nếu có)',
  `ti_le` decimal(5,2) NOT NULL COMMENT 'Tỉ lệ đột phá cuối cùng (%)',
  `ti_le_co_ban` decimal(5,2) NOT NULL COMMENT 'Tỉ lệ cơ bản',
  `bonus_dao_cu` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Bonus từ đạo cụ',
  `bonus_that_bai` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Bonus từ thất bại liên tiếp',
  `thanh_cong` tinyint NOT NULL,
  `thoi_diem` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_dplc_cu` (`linh_can_id_cu`),
  KEY `fk_dplc_moi` (`linh_can_id_moi`),
  KEY `fk_dplc_dao_cu` (`dao_cu_id`),
  KEY `idx_dplc_player` (`player_id`,`thoi_diem`),
  CONSTRAINT `fk_dplc_cu` FOREIGN KEY (`linh_can_id_cu`) REFERENCES `tmpl_linh_can` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_dplc_dao_cu` FOREIGN KEY (`dao_cu_id`) REFERENCES `tmpl_dao_cu` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dplc_moi` FOREIGN KEY (`linh_can_id_moi`) REFERENCES `tmpl_linh_can` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_dplc_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_dplc_thanh_cong` CHECK ((`thanh_cong` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Log đột phá phẩm cấp linh căn. Dùng để audit và balance';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_dot_pha_linh_can`
--

LOCK TABLES `log_dot_pha_linh_can` WRITE;
/*!40000 ALTER TABLE `log_dot_pha_linh_can` DISABLE KEYS */;
INSERT INTO `log_dot_pha_linh_can` VALUES (1,7,6,7,NULL,100.00,100.00,0.00,0.00,1,'2026-09-15 07:42:50'),(2,7,7,8,NULL,25.00,25.00,0.00,0.00,1,'2026-09-15 08:42:46'),(3,7,8,9,29,75.00,25.00,50.00,0.00,1,'2026-09-15 08:53:08'),(4,7,11,12,27,85.00,25.00,60.00,0.00,1,'2026-09-15 09:08:47');
/*!40000 ALTER TABLE `log_dot_pha_linh_can` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_giao_dich`
--

DROP TABLE IF EXISTS `log_giao_dich`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_giao_dich` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `loai` enum('Mua','Ban') COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` int unsigned NOT NULL,
  `so_luong` int unsigned NOT NULL,
  `gia_linh_thach` bigint unsigned NOT NULL DEFAULT '0',
  `gia_tien_ngoc` bigint unsigned NOT NULL DEFAULT '0',
  `thoi_diem` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_gd_player` (`player_id`,`thoi_diem`),
  CONSTRAINT `fk_lgd_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_giao_dich`
--

LOCK TABLES `log_giao_dich` WRITE;
/*!40000 ALTER TABLE `log_giao_dich` DISABLE KEYS */;
INSERT INTO `log_giao_dich` VALUES (1,7,'Mua','DanDuoc',9,2,300,0,'2026-09-14 10:46:55'),(2,7,'Ban','LinhThao',15,1,100000,0,'2026-09-14 10:47:51'),(3,7,'Mua','Exchange',0,3,30000,3,'2026-09-14 10:53:44'),(4,7,'Mua','CongPhap',5,3,15000,0,'2026-09-14 12:49:02'),(5,7,'Ban','CongPhap',5,3,7500,0,'2026-09-14 12:50:29');
/*!40000 ALTER TABLE `log_giao_dich` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_lichluyen`
--

DROP TABLE IF EXISTS `log_lichluyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_lichluyen` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `dia_diem_id` tinyint unsigned NOT NULL,
  `ket_qua` json NOT NULL,
  `tong_linh_thach` bigint unsigned NOT NULL DEFAULT '0',
  `tong_tu_vi` bigint unsigned NOT NULL DEFAULT '0',
  `thoi_diem` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_ll` (`player_id`,`thoi_diem`),
  KEY `fk_ll_dia_diem` (`dia_diem_id`),
  CONSTRAINT `fk_ll_dia_diem` FOREIGN KEY (`dia_diem_id`) REFERENCES `tmpl_dia_diem` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_ll_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_lichluyen`
--

LOCK TABLES `log_lichluyen` WRITE;
/*!40000 ALTER TABLE `log_lichluyen` DISABLE KEYS */;
INSERT INTO `log_lichluyen` VALUES (2,7,4,'[{\"ten\": \"Bị Tà Tu Chặn Cướp\", \"emoji\": \"💀\", \"mo_ta\": \"-0 linh thạch (12%)\"}, {\"ten\": \"Gặp Thương Nhân Thần Bí\", \"emoji\": \"🧙\", \"mo_ta\": \"Tặng +177 exp & tu vi\"}, {\"ten\": \"Gặp Thương Nhân Thần Bí\", \"emoji\": \"🧙\", \"mo_ta\": \"Tặng +152 linh thạch\"}]',152,177,'2026-09-13 19:54:24'),(3,7,1,'[{\"ten\": \"Gặp Thương Nhân Thần Bí\", \"emoji\": \"🧙\", \"mo_ta\": \"Tặng +197 exp & tu vi\"}, {\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+160 linh thạch\"}, {\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+24 exp & tu vi\"}]',160,221,'2026-09-13 19:57:37'),(4,7,1,'[{\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+158 linh thạch\"}, {\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+15 exp & tu vi\"}, {\"ten\": \"Chiến Đấu Yêu Thú\", \"emoji\": \"🐺\", \"mo_ta\": \"Chiến đấu! -5 HP\"}]',158,15,'2026-09-13 20:02:17'),(5,7,3,'[{\"ten\": \"Sập Bẫy\", \"emoji\": \"💥\", \"mo_ta\": \"-11 HP (11%)\"}, {\"ten\": \"Gặp Thương Nhân Thần Bí\", \"emoji\": \"🧙\", \"mo_ta\": \"Tặng +146 exp & tu vi\"}, {\"ten\": \"Gặp Thương Nhân Thần Bí\", \"emoji\": \"🧙\", \"mo_ta\": \"Tặng +97 exp & tu vi\"}]',0,243,'2026-09-13 20:14:25'),(6,7,6,'[{\"ten\": \"Sập Bẫy\", \"emoji\": \"💥\", \"mo_ta\": \"-6 HP (6%)\"}, {\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+27 exp & tu vi\"}, {\"ten\": \"Chiến Đấu Yêu Thú\", \"emoji\": \"🐺\", \"mo_ta\": \"Chiến đấu! -4 HP\"}]',0,27,'2026-09-13 20:34:06'),(7,7,1,'[{\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+25 exp & tu vi\"}, {\"ten\": \"Nhặt Linh Thảo\", \"emoji\": \"🌿\", \"mo_ta\": \"+2× Long Huyết Thảo\"}, {\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+218 linh thạch\"}]',218,25,'2026-09-13 20:38:23'),(8,7,3,'[{\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+19 exp & tu vi\"}, {\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+27 exp & tu vi\"}, {\"ten\": \"Bình Yên\", \"emoji\": \"😌\", \"mo_ta\": \"Không có gì xảy ra\"}]',0,46,'2026-09-14 07:57:01'),(9,7,4,'[{\"ten\": \"Phát Hiện Đan Phương\", \"emoji\": \"📜\", \"mo_ta\": \"Không có gì\"}, {\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+338 linh thạch\"}, {\"ten\": \"Gặp Thương Nhân Thần Bí\", \"emoji\": \"🧙\", \"mo_ta\": \"Tặng +127 exp & tu vi\"}]',338,127,'2026-09-14 08:06:57'),(10,7,2,'[{\"ten\": \"Bị Tà Tu Chặn Cướp\", \"emoji\": \"💀\", \"mo_ta\": \"-71 linh thạch (7%)\"}, {\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+21 exp & tu vi\"}, {\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+291 linh thạch\"}]',291,21,'2026-09-14 08:22:02'),(11,7,4,'[{\"ten\": \"Phát Hiện Đan Phương\", \"emoji\": \"📜\", \"mo_ta\": \"Công thức: **Linh Lực Đan**\"}, {\"ten\": \"Sập Bẫy\", \"emoji\": \"💥\", \"mo_ta\": \"-8 HP (5%)\"}, {\"ten\": \"Gặp Thương Nhân Thần Bí\", \"emoji\": \"🧙\", \"mo_ta\": \"Tặng +304 exp & tu vi\"}]',0,304,'2026-09-14 08:46:59'),(12,7,6,'[{\"ten\": \"Phát Hiện Đan Phương\", \"emoji\": \"📜\", \"mo_ta\": \"Công thức: **Hồi Xuân Đan**\"}, {\"ten\": \"Phát Hiện Đan Phương\", \"emoji\": \"📜\", \"mo_ta\": \"Không có gì\"}, {\"ten\": \"Bị Tà Tu Chặn Cướp\", \"emoji\": \"💀\", \"mo_ta\": \"-174 linh thạch (14%)\"}]',0,0,'2026-09-14 09:01:36'),(13,7,1,'[{\"ten\": \"Bị Tà Tu Chặn Cướp\", \"emoji\": \"💀\", \"mo_ta\": \"-139 linh thạch (13%)\"}, {\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+543 linh thạch\"}, {\"ten\": \"Chiến Đấu Yêu Thú\", \"emoji\": \"🐺\", \"mo_ta\": \"Chiến đấu! -17 HP\"}]',543,0,'2026-09-14 09:08:43'),(14,7,6,'[{\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+226 linh thạch\"}, {\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+1,404 linh thạch\"}, {\"ten\": \"Chiến Đấu Yêu Thú\", \"emoji\": \"🐺\", \"mo_ta\": \"Chiến đấu! -30 HP\"}]',1630,0,'2026-09-14 10:54:04'),(15,7,5,'[{\"ten\": \"Bình Yên\", \"emoji\": \"😌\", \"mo_ta\": \"Không có gì xảy ra\"}, {\"ten\": \"Nhặt Linh Thảo\", \"emoji\": \"🌿\", \"mo_ta\": \"+1× Long Tiên Thảo\"}, {\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+130 exp & tu vi\"}]',0,130,'2026-09-14 11:06:22'),(16,7,4,'[{\"ten\": \"Chiến Đấu Yêu Thú\", \"emoji\": \"🐺\", \"mo_ta\": \"Chiến đấu! -17 HP\"}, {\"ten\": \"Phát Hiện Đan Phương\", \"emoji\": \"📜\", \"mo_ta\": \"+1× Đan phương: **Tụ Linh Đan**\"}, {\"ten\": \"Bị Tà Tu Chặn Cướp\", \"emoji\": \"💀\", \"mo_ta\": \"-317,142 linh thạch (14%)\"}]',0,0,'2026-09-14 21:06:41'),(17,7,1,'[{\"ten\": \"Bị Tà Tu Chặn Cướp\", \"emoji\": \"💀\", \"mo_ta\": \"-175,334 linh thạch (9%)\"}, {\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+102 exp & tu vi\"}, {\"ten\": \"Nhận Linh Thạch\", \"emoji\": \"💰\", \"mo_ta\": \"+386 linh thạch\"}]',386,102,'2026-09-15 07:15:06'),(18,7,6,'[{\"ten\": \"Khai Thác Khoáng Thạch\", \"emoji\": \"⛰\", \"mo_ta\": \"+10× **Thanh Tùng Mộc**\"}, {\"ten\": \"Bị Tà Tu Chặn Cướp\", \"emoji\": \"💀\", \"mo_ta\": \"-159,605 linh thạch (9%)\"}, {\"ten\": \"Khai Thác Khoáng Thạch\", \"emoji\": \"⛰\", \"mo_ta\": \"+7× **Huyền Thiết**\"}]',0,0,'2026-09-15 10:27:17'),(19,7,4,'[{\"ten\": \"Bình Yên\", \"emoji\": \"😌\", \"mo_ta\": \"Không có gì xảy ra\"}, {\"ten\": \"Đốn Ngộ\", \"emoji\": \"✨\", \"mo_ta\": \"**Mộc Linh Căn - Cực** +8% → `8.00%`\"}, {\"ten\": \"Gặp Thương Nhân Thần Bí\", \"emoji\": \"🧙\", \"mo_ta\": \"Tặng +342 linh thạch\"}]',342,0,'2026-09-15 10:45:53'),(20,7,2,'[{\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+53 exp & tu vi\"}, {\"ten\": \"Ngộ Đạo\", \"emoji\": \"🔮\", \"mo_ta\": \"+66 exp & tu vi\"}, {\"ten\": \"Bị Tà Tu Chặn Cướp\", \"emoji\": \"💀\", \"mo_ta\": \"-129,130 linh thạch (8%)\"}]',0,119,'2026-09-15 10:49:06');
/*!40000 ALTER TABLE `log_lichluyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_su_kien`
--

DROP TABLE IF EXISTS `log_su_kien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_su_kien` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned DEFAULT NULL,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` json NOT NULL,
  `thoi_diem` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_event` (`event_type`,`thoi_diem`),
  KEY `fk_lsk_player` (`player_id`),
  CONSTRAINT `fk_lsk_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Log chung. Ghi mọi event: giao dịch, chiến đấu, sự kiện...';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_su_kien`
--

LOCK TABLES `log_su_kien` WRITE;
/*!40000 ALTER TABLE `log_su_kien` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_su_kien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `misc_tui_do`
--

DROP TABLE IF EXISTS `misc_tui_do`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `misc_tui_do` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `item_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `so_luong` int unsigned NOT NULL,
  `metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tui_do` (`player_id`,`item_code`),
  CONSTRAINT `fk_tui_do_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `misc_tui_do`
--

LOCK TABLES `misc_tui_do` WRITE;
/*!40000 ALTER TABLE `misc_tui_do` DISABLE KEYS */;
INSERT INTO `misc_tui_do` VALUES (7,7,'dan_phuong_47',1,'{\"ten\": \"Đại Huyết Nguyên Đan\", \"dan_duoc_id\": 47}'),(11,7,'cong_phap_28',1,'{\"ten\": \"Cửu U Băng Kinh\", \"cong_phap_id\": 28}'),(12,7,'cong_phap_1',7,'{\"ten\": \"Kim Cang Quyết\", \"cong_phap_id\": 1}');
/*!40000 ALTER TABLE `misc_tui_do` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player` (
  `player_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `discord_id` bigint unsigned NOT NULL,
  `ten_nhan_vat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `canh_gioi_id` tinyint unsigned NOT NULL,
  `tang_canh_gioi` tinyint unsigned NOT NULL DEFAULT '1',
  `tang_tich_luy` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'Tầng tích lũy xuyên cảnh giới (1-90)',
  `exp` bigint unsigned NOT NULL DEFAULT '0',
  `tu_vi` bigint unsigned NOT NULL DEFAULT '0',
  `linh_thach` bigint unsigned NOT NULL DEFAULT '0',
  `tien_ngoc` bigint unsigned NOT NULL DEFAULT '0',
  `tam_canh` int NOT NULL DEFAULT '0',
  `khi_van` int NOT NULL DEFAULT '0',
  `so_du_lan_dot_pha` int unsigned NOT NULL DEFAULT '0' COMMENT 'Số lần đột phá thất bại liên tiếp',
  `ti_le_dot_pha_them` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Tỉ lệ đột phá cộng thêm từ thất bại liên tiếp (%)',
  `last_dot_pha` datetime DEFAULT NULL COMMENT 'Lần đột phá cuối cùng',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_active` datetime DEFAULT NULL,
  `is_banned` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`),
  UNIQUE KEY `uk_player_discord` (`discord_id`),
  UNIQUE KEY `uk_player_ten` (`ten_nhan_vat`),
  KEY `idx_canh_gioi` (`canh_gioi_id`,`tang_canh_gioi`),
  KEY `idx_tu_vi` (`tu_vi`),
  CONSTRAINT `fk_player_canh_gioi` FOREIGN KEY (`canh_gioi_id`) REFERENCES `canh_gioi` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='hp_hien_tai/mp_hien_tai đã chuyển vào player_stat';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES (7,1283375479537270846,'fvjnffd',3,9,27,77830,31679,1485004,2003,0,0,1,0.00,'2026-09-15 10:26:54','2026-09-13 19:37:17','2026-09-15 10:49:15',NULL,0);
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_backup_20260914`
--

DROP TABLE IF EXISTS `player_backup_20260914`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_backup_20260914` (
  `player_id` bigint unsigned NOT NULL DEFAULT '0',
  `discord_id` bigint unsigned NOT NULL,
  `ten_nhan_vat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `canh_gioi_id` tinyint unsigned NOT NULL,
  `tang_canh_gioi` tinyint unsigned NOT NULL DEFAULT '1',
  `tang_tich_luy` tinyint unsigned NOT NULL DEFAULT '1' COMMENT 'Tầng tích lũy xuyên cảnh giới (1-90)',
  `exp` bigint unsigned NOT NULL DEFAULT '0',
  `tu_vi` bigint unsigned NOT NULL DEFAULT '0',
  `linh_thach` bigint unsigned NOT NULL DEFAULT '0',
  `tien_ngoc` bigint unsigned NOT NULL DEFAULT '0',
  `tam_canh` int NOT NULL DEFAULT '0',
  `khi_van` int NOT NULL DEFAULT '0',
  `so_du_lan_dot_pha` int unsigned NOT NULL DEFAULT '0' COMMENT 'Số lần đột phá thất bại liên tiếp',
  `ti_le_dot_pha_them` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Tỉ lệ đột phá cộng thêm từ thất bại liên tiếp (%)',
  `last_dot_pha` datetime DEFAULT NULL COMMENT 'Lần đột phá cuối cùng',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_active` datetime DEFAULT NULL,
  `is_banned` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_backup_20260914`
--

LOCK TABLES `player_backup_20260914` WRITE;
/*!40000 ALTER TABLE `player_backup_20260914` DISABLE KEYS */;
INSERT INTO `player_backup_20260914` VALUES (7,1283375479537270846,'fvjnffd',2,10,1,61,967,1246,0,0,0,0,0.00,'2026-09-14 08:08:05','2026-09-13 19:37:17','2026-09-14 08:36:36',NULL,0);
/*!40000 ALTER TABLE `player_backup_20260914` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_buff`
--

DROP TABLE IF EXISTS `player_buff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_buff` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `player_id` bigint unsigned NOT NULL,
  `buff_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Mã buff/debuff (VD: bong, te_liet, buff_atk)',
  `effect` json NOT NULL COMMENT 'Hiệu ứng JSON: {"dmg_per_turn":30,"turns":5}',
  `stack` smallint unsigned NOT NULL DEFAULT '1' COMMENT 'Số stack chồng (tối đa tùy loại buff)',
  `bat_dau_luc` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời điểm bắt đầu buff',
  `het_han_luc` datetime NOT NULL COMMENT 'Thời điểm hết hạn',
  `nguon_goc` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nguồn gây buff (VD: dan_bao_khi, boss_skill)',
  `cap_nhat_luc` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Lần cập nhật cuối (kéo dài thời gian)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_buff_player_code` (`player_id`,`buff_code`),
  KEY `idx_buff_expire` (`player_id`,`het_han_luc`),
  KEY `idx_buff_code` (`buff_code`,`het_han_luc`),
  CONSTRAINT `fk_buff_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_buff_stack` CHECK ((`stack` >= 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Buff/debuff tạm. Cùng buff_code sẽ KÉO DÀI thời gian thay vì tạo mới';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_buff`
--

LOCK TABLES `player_buff` WRITE;
/*!40000 ALTER TABLE `player_buff` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_buff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_bxh_tuan`
--

DROP TABLE IF EXISTS `player_bxh_tuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_bxh_tuan` (
  `player_id` bigint unsigned NOT NULL,
  `loai_bxh` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Mã BXH seasonal',
  `tuan` date NOT NULL COMMENT 'Ngày thứ 2 đầu tuần',
  `gia_tri` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`loai_bxh`,`tuan`),
  KEY `idx_pbt_loai_tuan` (`loai_bxh`,`tuan`,`gia_tri` DESC),
  CONSTRAINT `fk_pbt_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stat tích lũy hàng tuần cho seasonal BXH';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_bxh_tuan`
--

LOCK TABLES `player_bxh_tuan` WRITE;
/*!40000 ALTER TABLE `player_bxh_tuan` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_bxh_tuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_cong_phap`
--

DROP TABLE IF EXISTS `player_cong_phap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_cong_phap` (
  `player_id` bigint unsigned NOT NULL,
  `cong_phap_id` int unsigned NOT NULL,
  `tang_hien_tai` tinyint unsigned NOT NULL DEFAULT '1',
  `do_thuan_thuc` decimal(5,2) NOT NULL DEFAULT '0.00',
  `dang_tu_luyen` tinyint NOT NULL DEFAULT '0',
  `ngay_hoc` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`player_id`,`cong_phap_id`),
  KEY `fk_pcp_cong_phap` (`cong_phap_id`),
  CONSTRAINT `fk_pcp_cong_phap` FOREIGN KEY (`cong_phap_id`) REFERENCES `tmpl_cong_phap` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pcp_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_cong_phap`
--

LOCK TABLES `player_cong_phap` WRITE;
/*!40000 ALTER TABLE `player_cong_phap` DISABLE KEYS */;
INSERT INTO `player_cong_phap` VALUES (7,1,2,3.00,1,'2026-09-14 12:10:56'),(7,11,1,5.00,1,'2026-09-14 12:13:48'),(7,32,1,0.00,0,'2026-09-15 09:22:02'),(7,33,1,0.00,0,'2026-09-15 09:21:44');
/*!40000 ALTER TABLE `player_cong_phap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_cooldown`
--

DROP TABLE IF EXISTS `player_cooldown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_cooldown` (
  `player_id` bigint unsigned NOT NULL,
  `action_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `san_sang_luc` datetime NOT NULL,
  PRIMARY KEY (`player_id`,`action_code`),
  CONSTRAINT `fk_cd_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_cooldown`
--

LOCK TABLES `player_cooldown` WRITE;
/*!40000 ALTER TABLE `player_cooldown` DISABLE KEYS */;
INSERT INTO `player_cooldown` VALUES (7,'dotpha','2026-09-15 14:26:54'),(7,'lichluyen','2026-09-15 10:52:07'),(7,'tuluyen','2026-09-15 10:51:15');
/*!40000 ALTER TABLE `player_cooldown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_daily`
--

DROP TABLE IF EXISTS `player_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_daily` (
  `player_id` bigint unsigned NOT NULL,
  `ngay_cuoi` date NOT NULL COMMENT 'Ngày điểm danh cuối (theo múi giờ VN)',
  `streak` int unsigned NOT NULL DEFAULT '0' COMMENT 'Chuỗi ngày điểm danh liên tiếp',
  `tong_linh_thach` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Tổng linh thạch nhận từ daily',
  `so_lan_diem_danh` int unsigned NOT NULL DEFAULT '0' COMMENT 'Tổng số lần điểm danh',
  PRIMARY KEY (`player_id`),
  CONSTRAINT `fk_pd_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Điểm danh hàng ngày của player';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_daily`
--

LOCK TABLES `player_daily` WRITE;
/*!40000 ALTER TABLE `player_daily` DISABLE KEYS */;
INSERT INTO `player_daily` VALUES (7,'2026-09-15',1,181,1);
/*!40000 ALTER TABLE `player_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_dan_duoc`
--

DROP TABLE IF EXISTS `player_dan_duoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_dan_duoc` (
  `player_id` bigint unsigned NOT NULL,
  `dan_duoc_id` int unsigned NOT NULL,
  `so_luong` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`dan_duoc_id`),
  KEY `fk_pdd_dan_duoc` (`dan_duoc_id`),
  CONSTRAINT `fk_pdd_dan_duoc` FOREIGN KEY (`dan_duoc_id`) REFERENCES `tmpl_dan_duoc` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pdd_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_dan_duoc`
--

LOCK TABLES `player_dan_duoc` WRITE;
/*!40000 ALTER TABLE `player_dan_duoc` DISABLE KEYS */;
INSERT INTO `player_dan_duoc` VALUES (7,1,1),(7,9,1);
/*!40000 ALTER TABLE `player_dan_duoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_dan_gioi_han`
--

DROP TABLE IF EXISTS `player_dan_gioi_han`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_dan_gioi_han` (
  `player_id` bigint unsigned NOT NULL,
  `dan_duoc_id` int unsigned NOT NULL,
  `canh_gioi_id` tinyint unsigned NOT NULL COMMENT 'Cảnh giới đang đột phá khi dùng đan',
  `so_lan_da_dung` int unsigned NOT NULL DEFAULT '1' COMMENT 'Số lần đã dùng cho cảnh giới này',
  `lan_dung_cuoi` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Lần dùng cuối',
  PRIMARY KEY (`player_id`,`dan_duoc_id`,`canh_gioi_id`),
  KEY `fk_pdgh_dan` (`dan_duoc_id`),
  KEY `fk_pdgh_canh_gioi` (`canh_gioi_id`),
  CONSTRAINT `fk_pdgh_canh_gioi` FOREIGN KEY (`canh_gioi_id`) REFERENCES `canh_gioi` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pdgh_dan` FOREIGN KEY (`dan_duoc_id`) REFERENCES `tmpl_dan_duoc` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pdgh_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Tracking giới hạn dùng đan theo cảnh giới';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_dan_gioi_han`
--

LOCK TABLES `player_dan_gioi_han` WRITE;
/*!40000 ALTER TABLE `player_dan_gioi_han` DISABLE KEYS */;
/*!40000 ALTER TABLE `player_dan_gioi_han` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_dan_phuong_hoc`
--

DROP TABLE IF EXISTS `player_dan_phuong_hoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_dan_phuong_hoc` (
  `player_id` bigint unsigned NOT NULL,
  `dan_duoc_id` int unsigned NOT NULL,
  `so_lan_nghien_cuu` int unsigned NOT NULL DEFAULT '0' COMMENT 'Số lần học trùng, mỗi lần +1% tỉ lệ cơ bản',
  `ngay_hoc` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`player_id`,`dan_duoc_id`),
  KEY `fk_pdph_dan_duoc` (`dan_duoc_id`),
  CONSTRAINT `fk_pdph_dan_duoc` FOREIGN KEY (`dan_duoc_id`) REFERENCES `tmpl_dan_duoc` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pdph_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_dan_phuong_hoc`
--

LOCK TABLES `player_dan_phuong_hoc` WRITE;
/*!40000 ALTER TABLE `player_dan_phuong_hoc` DISABLE KEYS */;
INSERT INTO `player_dan_phuong_hoc` VALUES (7,1,1,'2026-09-14 21:02:05'),(7,3,0,'2026-09-14 12:10:43'),(7,34,0,'2026-09-14 21:07:59');
/*!40000 ALTER TABLE `player_dan_phuong_hoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_dao_cu`
--

DROP TABLE IF EXISTS `player_dao_cu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_dao_cu` (
  `player_id` bigint unsigned NOT NULL,
  `dao_cu_id` smallint unsigned NOT NULL,
  `so_luong` int unsigned NOT NULL DEFAULT '0',
  `ngay_nhan` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày nhận đạo cụ đầu tiên',
  `cap_nhat_luc` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`player_id`,`dao_cu_id`),
  KEY `idx_pdc_dao_cu` (`dao_cu_id`),
  CONSTRAINT `fk_pdc_dao_cu` FOREIGN KEY (`dao_cu_id`) REFERENCES `tmpl_dao_cu` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pdc_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_pdc_so_luong` CHECK ((`so_luong` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Đạo cụ player sở hữu';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_dao_cu`
--

LOCK TABLES `player_dao_cu` WRITE;
/*!40000 ALTER TABLE `player_dao_cu` DISABLE KEYS */;
INSERT INTO `player_dao_cu` VALUES (7,6,5,'2026-09-14 21:36:11','2026-09-15 08:41:19'),(7,7,2,'2026-09-15 08:41:33','2026-09-15 08:41:59'),(7,8,8,'2026-09-15 09:07:54','2026-09-15 09:08:20'),(7,14,1,'2026-09-15 07:26:38','2026-09-15 08:43:10'),(7,20,5,'2026-09-14 12:48:28','2026-09-14 12:48:28'),(7,27,4,'2026-09-15 08:44:20','2026-09-15 09:08:47');
/*!40000 ALTER TABLE `player_dao_cu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_khoang_thach`
--

DROP TABLE IF EXISTS `player_khoang_thach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_khoang_thach` (
  `player_id` bigint unsigned NOT NULL,
  `khoang_thach_id` smallint unsigned NOT NULL,
  `so_luong` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`khoang_thach_id`),
  KEY `idx_pkt_khoang_thach` (`khoang_thach_id`),
  CONSTRAINT `fk_pkt_khoang_thach` FOREIGN KEY (`khoang_thach_id`) REFERENCES `tmpl_khoang_thach` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pkt_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_khoang_thach`
--

LOCK TABLES `player_khoang_thach` WRITE;
/*!40000 ALTER TABLE `player_khoang_thach` DISABLE KEYS */;
INSERT INTO `player_khoang_thach` VALUES (7,6,7),(7,11,10);
/*!40000 ALTER TABLE `player_khoang_thach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_linh_can`
--

DROP TABLE IF EXISTS `player_linh_can`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_linh_can` (
  `player_id` bigint unsigned NOT NULL,
  `linh_can_id` smallint unsigned NOT NULL,
  `do_tinh_khiet` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Độ tinh khiết 0-100%. Đạt 100% có thể đột phá phẩm cấp',
  `so_lan_dung_dao_cu_dot_pha` tinyint unsigned NOT NULL DEFAULT '0' COMMENT 'Số lần đã dùng đạo cụ tăng tỉ lệ (max 2, reset sau đột phá)',
  `san_sang_dot_pha` tinyint NOT NULL DEFAULT '0' COMMENT '1 = đã đủ 100% tinh khiết, sẵn sàng đột phá',
  `so_lan_dot_pha_that_bai` int unsigned NOT NULL DEFAULT '0' COMMENT 'Số lần đột phá thất bại (dùng để cộng tỉ lệ lần sau)',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '1 = đang kích hoạt, 0 = không dùng',
  `ngay_nhan` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày nhận linh căn',
  `cap_nhat_luc` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Lần cập nhật cuối',
  PRIMARY KEY (`player_id`,`linh_can_id`),
  KEY `fk_plc_linh_can` (`linh_can_id`),
  KEY `idx_plc_player_active` (`player_id`,`is_active`),
  KEY `idx_plc_san_sang` (`player_id`,`san_sang_dot_pha`),
  CONSTRAINT `fk_plc_linh_can` FOREIGN KEY (`linh_can_id`) REFERENCES `tmpl_linh_can` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_plc_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_is_active` CHECK ((`is_active` in (0,1))),
  CONSTRAINT `chk_san_sang` CHECK ((`san_sang_dot_pha` in (0,1))),
  CONSTRAINT `chk_tinh_khiet` CHECK ((`do_tinh_khiet` between 0 and 100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Linh căn player sở hữu. Cày độ tinh khiết để đột phá phẩm cấp';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_linh_can`
--

LOCK TABLES `player_linh_can` WRITE;
/*!40000 ALTER TABLE `player_linh_can` DISABLE KEYS */;
INSERT INTO `player_linh_can` VALUES (7,1,0.00,0,0,0,1,'2026-09-13 19:37:17','2026-09-13 19:37:17'),(7,9,8.00,0,0,0,1,'2026-09-15 08:53:08','2026-09-15 10:45:53'),(7,12,0.00,0,0,0,1,'2026-09-15 09:08:47','2026-09-15 09:08:47');
/*!40000 ALTER TABLE `player_linh_can` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_linh_thao`
--

DROP TABLE IF EXISTS `player_linh_thao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_linh_thao` (
  `player_id` bigint unsigned NOT NULL,
  `linh_thao_id` int unsigned NOT NULL,
  `so_luong` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`linh_thao_id`),
  KEY `fk_plt_linh_thao` (`linh_thao_id`),
  CONSTRAINT `fk_plt_linh_thao` FOREIGN KEY (`linh_thao_id`) REFERENCES `tmpl_linh_thao` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_plt_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_linh_thao`
--

LOCK TABLES `player_linh_thao` WRITE;
/*!40000 ALTER TABLE `player_linh_thao` DISABLE KEYS */;
INSERT INTO `player_linh_thao` VALUES (7,1,1),(7,3,4),(7,11,1),(7,15,1),(7,18,4);
/*!40000 ALTER TABLE `player_linh_thao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_nghe_nghiep`
--

DROP TABLE IF EXISTS `player_nghe_nghiep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_nghe_nghiep` (
  `player_id` bigint unsigned NOT NULL,
  `nghe_nghiep_id` tinyint unsigned NOT NULL,
  `cap_do` tinyint unsigned NOT NULL DEFAULT '1',
  `kinh_nghiem` bigint unsigned NOT NULL DEFAULT '0',
  `danh_vong` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`,`nghe_nghiep_id`),
  KEY `fk_pnn_nghe` (`nghe_nghiep_id`),
  CONSTRAINT `fk_pnn_nghe` FOREIGN KEY (`nghe_nghiep_id`) REFERENCES `tmpl_nghe_nghiep` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pnn_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_nghe_nghiep`
--

LOCK TABLES `player_nghe_nghiep` WRITE;
/*!40000 ALTER TABLE `player_nghe_nghiep` DISABLE KEYS */;
INSERT INTO `player_nghe_nghiep` VALUES (7,3,1,0,0);
/*!40000 ALTER TABLE `player_nghe_nghiep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_stat`
--

DROP TABLE IF EXISTS `player_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `player_stat` (
  `player_id` bigint unsigned NOT NULL,
  `hp_max` int unsigned NOT NULL DEFAULT '0',
  `mp_max` int unsigned NOT NULL DEFAULT '0',
  `atk` int unsigned NOT NULL DEFAULT '0',
  `def` int unsigned NOT NULL DEFAULT '0',
  `matk` int unsigned NOT NULL DEFAULT '0',
  `mdef` int unsigned NOT NULL DEFAULT '0',
  `hp_max_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `mp_max_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `hp_hien_tai` int unsigned NOT NULL DEFAULT '0',
  `mp_hien_tai` int unsigned NOT NULL DEFAULT '0',
  `ti_le_ne` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_chinh_xac` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_chi_mang` decimal(5,2) NOT NULL DEFAULT '5.00',
  `sat_thuong_chi_mang` decimal(5,2) NOT NULL DEFAULT '150.00',
  `ti_le_khang_chi_mang` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_xuyen_giap` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_xuyen_phep` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_hut_mau` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_hoi_mp` decimal(5,2) NOT NULL DEFAULT '0.00',
  `giam_sat_thuong_nhan` decimal(5,2) NOT NULL DEFAULT '0.00',
  `giam_hoi_chieu` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_kim` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_moc` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_thuy` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_hoa` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_tho` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_loi` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_bang` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_phong` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_duong` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khang_am` decimal(5,2) NOT NULL DEFAULT '0.00',
  `toc_do_tu_luyen` decimal(5,2) NOT NULL DEFAULT '100.00',
  `ti_le_dot_pha` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Bonus tỉ lệ đột phá từ stat (%)',
  `ti_le_ngo_dao` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tam_canh_bonus` decimal(5,2) NOT NULL DEFAULT '0.00',
  `khi_van_bonus` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_thanh_cong_do_kiep` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_gay_bong` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sat_thuong_bong_moi_luot` int unsigned NOT NULL DEFAULT '0',
  `ti_le_gay_te_liet` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_gay_dong_bang` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_gay_mu` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_gay_roi_loan` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ti_le_kich_hoat_hoi_hp` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Xác suất kích hoạt hồi HP mỗi lượt (%)',
  `phan_tram_hoi_hp_moi_luot` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '% HP_max hồi mỗi lượt khi kích hoạt',
  `hieu_ung_hoi_phuc_bonus` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Bonus % nhân vào lượng hồi phục',
  `bonus_ti_le_roi_do` decimal(5,2) NOT NULL DEFAULT '0.00',
  `bonus_ti_le_roi_linh_thach` decimal(5,2) NOT NULL DEFAULT '0.00',
  `is_dirty` tinyint NOT NULL DEFAULT '1',
  `cap_nhat_luc` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_hp_update` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời điểm HP được update lần cuối',
  `in_combat` tinyint NOT NULL DEFAULT '0' COMMENT '1 = đang combat (không hồi HP), 0 = ngoài combat (hồi 1%/s)',
  `atk_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `def_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `matk_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `mdef_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`player_id`),
  CONSTRAINT `fk_pstat_player` FOREIGN KEY (`player_id`) REFERENCES `player` (`player_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_chi_mang` CHECK ((`ti_le_chi_mang` between 0 and 100)),
  CONSTRAINT `chk_giam_hoi_chieu` CHECK ((`giam_hoi_chieu` between 0 and 45)),
  CONSTRAINT `chk_khang` CHECK (((`khang_kim` between 0 and 90) and (`khang_moc` between 0 and 90) and (`khang_thuy` between 0 and 90) and (`khang_hoa` between 0 and 90) and (`khang_tho` between 0 and 90) and (`khang_loi` between 0 and 90) and (`khang_bang` between 0 and 90) and (`khang_phong` between 0 and 90) and (`khang_duong` between 0 and 90) and (`khang_am` between 0 and 90))),
  CONSTRAINT `chk_kich_hoat` CHECK ((`ti_le_kich_hoat_hoi_hp` between 0 and 100)),
  CONSTRAINT `chk_ne` CHECK ((`ti_le_ne` between 0 and 75)),
  CONSTRAINT `chk_phan_tram_hoi` CHECK ((`phan_tram_hoi_hp_moi_luot` between 0 and 50))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Wide table. is_dirty=1 → cần recompute';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_stat`
--

LOCK TABLES `player_stat` WRITE;
/*!40000 ALTER TABLE `player_stat` DISABLE KEYS */;
INSERT INTO `player_stat` VALUES (7,621,275,46,23,36,23,0.00,0.00,621,50,0.00,0.00,5.00,150.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,100.00,0.00,0.00,0.00,0.00,0.00,0.00,0,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,1,'2026-09-15 10:23:29','2026-09-15 10:23:29',0,0.00,0.00,0.00,0.00);
/*!40000 ALTER TABLE `player_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_bxh`
--

DROP TABLE IF EXISTS `tmpl_bxh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_bxh` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'VD: canh_gioi, linh_thach, exp_tuan',
  `ten` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emoji` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loai` enum('snapshot','seasonal') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'snapshot = không reset, seasonal = reset hàng tuần',
  `query_sql` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SQL lấy top, dùng {limit}',
  `order_column` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Cột dùng để sort (cho seasonal)',
  `table_nguon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Bảng nguồn (cho seasonal)',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `thu_tu` smallint unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_bxh_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Metadata các loại BXH. Thêm row mới = thêm BXH mới';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_bxh`
--

LOCK TABLES `tmpl_bxh` WRITE;
/*!40000 ALTER TABLE `tmpl_bxh` DISABLE KEYS */;
INSERT INTO `tmpl_bxh` VALUES (1,'canh_gioi','Cảnh giới','🌟','snapshot','SELECT p.player_id, p.discord_id, p.ten_nhan_vat, CONCAT(cg.ten, \' tầng \', p.tang_canh_gioi) AS gia_tri_hien_thi, p.canh_gioi_id AS gia_tri_sort FROM player p JOIN canh_gioi cg ON cg.id = p.canh_gioi_id ORDER BY p.canh_gioi_id DESC, p.tang_tich_luy DESC, p.exp DESC LIMIT {limit}',NULL,NULL,1,1),(2,'linh_thach','Linh thạch','💰','snapshot','SELECT player_id, discord_id, ten_nhan_vat, FORMAT(linh_thach, 0) AS gia_tri_hien_thi, linh_thach AS gia_tri_sort FROM player ORDER BY linh_thach DESC LIMIT {limit}',NULL,NULL,1,2),(3,'tu_vi','Tu vi','🔮','snapshot','SELECT player_id, discord_id, ten_nhan_vat, FORMAT(tu_vi, 0) AS gia_tri_hien_thi, tu_vi AS gia_tri_sort FROM player ORDER BY tu_vi DESC LIMIT {limit}',NULL,NULL,1,3),(4,'nghe_nghiep','Nghề nghiệp','⚒️','snapshot','SELECT p.player_id, p.discord_id, p.ten_nhan_vat, CONCAT(nn.ten, \' - Cấp \', pnn.cap_do) AS gia_tri_hien_thi, pnn.kinh_nghiem AS gia_tri_sort FROM player_nghe_nghiep pnn JOIN player p ON p.player_id = pnn.player_id JOIN tmpl_nghe_nghiep nn ON nn.id = pnn.nghe_nghiep_id ORDER BY pnn.kinh_nghiem DESC LIMIT {limit}',NULL,NULL,1,4);
/*!40000 ALTER TABLE `tmpl_bxh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_cong_phap`
--

DROP TABLE IF EXISTS `tmpl_cong_phap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_cong_phap` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ten` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loai` enum('NguHanh','DiHe','LuyenThe','LuyenHon') COLLATE utf8mb4_unicode_ci NOT NULL,
  `he` json DEFAULT NULL,
  `giai_cap` enum('Hoang','Huyen','Dia','Thien') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pham_cap` enum('Ha','Trung','Thuong','Cuc','HoanMy') COLLATE utf8mb4_unicode_ci NOT NULL,
  `so_tang` tinyint unsigned NOT NULL DEFAULT '9',
  `effect_moi_tang` json NOT NULL,
  `yeu_cau_canh_gioi_id` tinyint unsigned DEFAULT NULL,
  `bonus_dac_biet` json DEFAULT NULL COMMENT '{"dieu_kien": "Duong", "he_so": 1.5} cho LuyenThe',
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cong_phap` (`ten`,`giai_cap`,`pham_cap`),
  KEY `idx_loai_giai` (`loai`,`giai_cap`),
  KEY `fk_cp_canh_gioi` (`yeu_cau_canh_gioi_id`),
  CONSTRAINT `fk_cp_canh_gioi` FOREIGN KEY (`yeu_cau_canh_gioi_id`) REFERENCES `canh_gioi` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_cong_phap`
--

LOCK TABLES `tmpl_cong_phap` WRITE;
/*!40000 ALTER TABLE `tmpl_cong_phap` DISABLE KEYS */;
INSERT INTO `tmpl_cong_phap` VALUES (1,'Kim Cang Quyết','NguHanh','[\"Kim\"]','Hoang','Trung',9,'{\"atk\": 8, \"matk\": 4, \"ti_le_chi_mang\": 1, \"ti_le_xuyen_giap\": 1}',1,NULL,'Kim hệ công pháp cơ bản, tăng công kích và xuyên giáp'),(2,'Kim Phong Kiếm Pháp','NguHanh','[\"Kim\", \"Phong\"]','Huyen','Trung',9,'{\"atk\": 20, \"matk\": 6, \"ti_le_gay_mu\": 2, \"ti_le_chi_mang\": 2, \"ti_le_xuyen_giap\": 2}',2,NULL,'Kim hệ trung cấp, kiếm pháp sắc bén'),(3,'Thiên Kim Kiếm Quyết','NguHanh','[\"Kim\"]','Dia','Trung',9,'{\"atk\": 50, \"matk\": 10, \"ti_le_chi_mang\": 3, \"ti_le_xuyen_giap\": 4}',3,NULL,'Kim hệ cao cấp, kiếm khí phá vạn vật'),(4,'Kim Ô Thần Quyết','NguHanh','[\"Kim\", \"Hoa\"]','Thien','Trung',9,'{\"atk\": 120, \"matk\": 20, \"ti_le_chi_mang\": 5, \"ti_le_gay_bong\": 3.5, \"ti_le_xuyen_giap\": 6, \"sat_thuong_chi_mang\": 25, \"sat_thuong_bong_moi_luot\": 250}',4,NULL,'Kim hệ đỉnh cao, thần quyết vô song'),(5,'Mộc Linh Quyết','NguHanh','[\"Moc\"]','Hoang','Trung',9,'{\"matk\": 10, \"mdef\": 10, \"hp_max\": 200, \"hieu_ung_hoi_phuc_bonus\": 5}',1,NULL,'Mộc hệ công pháp cơ bản, tăng sinh lực'),(6,'Thanh Mộc Trường Sinh','NguHanh','[\"Moc\"]','Huyen','Trung',9,'{\"matk\": 10, \"mdef\": 20, \"hp_max\": 500, \"hieu_ung_hoi_phuc_bonus\": 6}',2,NULL,'Mộc hệ trung cấp, sinh mệnh dồi dào'),(7,'Thủy Mộc Sinh Quyết','NguHanh','[\"Moc\", \"Thuy\"]','Dia','Trung',9,'{\"matk\": 20, \"mdef\": 40, \"hp_max\": 1000, \"mp_max\": 200, \"ti_le_hoi_mp\": 2.5, \"giam_sat_thuong_nhan\": 1.5, \"hieu_ung_hoi_phuc_bonus\": 10}',3,NULL,'Mộc hệ cao cấp, sinh mệnh bất diệt'),(8,'Mộc Hoàng Chân Kinh','NguHanh','[\"Moc\"]','Thien','Trung',9,'{\"matk\": 100, \"mdef\": 100, \"hp_max\": 4000, \"hieu_ung_hoi_phuc_bonus\": 35}',4,NULL,'Mộc hệ đỉnh cao, chân lý sinh mệnh'),(9,'Thủy Nguyên Quyết','NguHanh','[\"Thuy\"]','Hoang','Trung',9,'{\"matk\": 5, \"mdef\": 10, \"mp_max\": 50, \"ti_le_hoi_mp\": 2}',1,NULL,'Thủy hệ công pháp cơ bản, tăng linh lực'),(10,'Huyền Thủy Kinh','NguHanh','[\"Thuy\"]','Huyen','Trung',9,'{\"matk\": 10, \"mdef\": 25, \"mp_max\": 120, \"ti_le_hoi_mp\": 3}',2,NULL,'Thủy hệ trung cấp, linh lực huyền diệu'),(11,'Bàn Nhược Tâm Kinh','NguHanh','[\"Thuy\", \"Tho\"]','Dia','Trung',9,'{\"def\": 40, \"matk\": 20, \"mdef\": 70, \"mp_max\": 300, \"ti_le_hoi_mp\": 4, \"giam_sat_thuong_nhan\": 2}',3,NULL,'Thủy hệ cao cấp, tâm như chỉ thủy'),(12,'Hoàng Tuyền Thủy Quyết','NguHanh','[\"Thuy\", \"Am\"]','Thien','Trung',9,'{\"matk\": 150, \"mdef\": 100, \"mp_max\": 800, \"ti_le_ne\": 3, \"ti_le_hoi_mp\": 5, \"ti_le_xuyen_phep\": 5, \"ti_le_gay_roi_loan\": 3}',4,NULL,'Thủy hệ đỉnh cao, hoàng tuyền độ vong'),(13,'Hỏa Diệm Quyết','NguHanh','[\"Hoa\"]','Hoang','Trung',9,'{\"atk\": 15, \"matk\": 10, \"mdef\": 10, \"ti_le_gay_bong\": 3, \"sat_thuong_bong_moi_luot\": 20}',1,NULL,'Hỏa hệ công pháp cơ bản, thiêu đốt vạn vật'),(14,'Liệt Hỏa Phần Thiên','NguHanh','[\"Hoa\"]','Huyen','Trung',9,'{\"atk\": 45, \"matk\": 15, \"mdef\": 15, \"ti_le_gay_bong\": 5, \"sat_thuong_bong_moi_luot\": 50}',2,NULL,'Hỏa hệ trung cấp, liệt hỏa phần thiên'),(15,'Cửu Dương Thần Công','NguHanh','[\"Hoa\", \"Duong\"]','Dia','Trung',9,'{\"atk\": 120, \"matk\": 50, \"mdef\": 50, \"ti_le_gay_bong\": 7, \"ti_le_kich_hoat_hoi_hp\": 5, \"phan_tram_hoi_hp_toi_da\": 1, \"sat_thuong_bong_moi_luot\": 180}',3,NULL,'Hỏa hệ cao cấp, cửu dương chí cương'),(16,'Thái Dương Chân Kinh','NguHanh','[\"Hoa\"]','Thien','Trung',9,'{\"atk\": 250, \"matk\": 100, \"mdef\": 80, \"ti_le_gay_bong\": 12, \"sat_thuong_bong_moi_luot\": 400}',4,NULL,'Hỏa hệ đỉnh cao, thái dương chi nguyên sơ'),(17,'Sa Thạch Quyết','NguHanh','[\"Tho\"]','Hoang','Trung',9,'{\"def\": 8, \"matk\": 10, \"mdef\": 35, \"hp_max\": 100, \"ti_le_gay_mu\": 2, \"giam_sat_thuong_nhan\": 3}',1,NULL,'Thổ hệ công pháp cơ bản, phòng ngự vững chắc'),(18,'Hậu Thổ Kinh','NguHanh','[\"Tho\"]','Huyen','Trung',9,'{\"def\": 30, \"matk\": 20, \"mdef\": 50, \"hp_max\": 200, \"giam_sat_thuong_nhan\": 3.5, \"ti_le_kich_hoat_hoi_hp\": 5, \"phan_tram_hoi_hp_toi_da\": 1}',2,NULL,'Thổ hệ trung cấp, hậu thổ chi lực'),(19,'Kim Cang Bất Hoại','NguHanh','[\"Tho\"]','Dia','Trung',9,'{\"def\": 50, \"matk\": 10, \"mdef\": 70, \"hp_max\": 300, \"giam_sat_thuong_nhan\": 5}',3,NULL,'Thổ hệ cao cấp, kim cang bất hoại'),(20,'Huyền Vũ Chân Kinh','NguHanh','[\"Tho\", \"Thuy\"]','Thien','Trung',9,'{\"def\": 120, \"matk\": 40, \"mdef\": 150, \"hp_max\": 700, \"ti_le_hoi_mp\": 2.5, \"giam_sat_thuong_nhan\": 10}',4,NULL,'Thổ hệ đỉnh cao, huyền vũ thần thú, trấn áp phương Bắc'),(21,'Lôi Đình Quyết','DiHe','[\"Loi\"]','Hoang','Trung',9,'{\"atk\": 10, \"matk\": 30, \"mdef\": 10, \"ti_le_gay_te_liet\": 2, \"ti_le_thanh_cong_do_kiep\": 2}',1,NULL,'Lôi hệ công pháp cơ bản, thiên lôi chi uy'),(22,'Chưởng Tâm Lôi Pháp','DiHe','[\"Loi\"]','Huyen','Trung',9,'{\"atk\": 25, \"matk\": 50, \"mdef\": 30, \"ti_le_gay_te_liet\": 4, \"ti_le_thanh_cong_do_kiep\": 2.5}',2,NULL,'Lôi hệ trung cấp, lôi pháp phá Si Mị Võng Lượng'),(23,'Cửu Tiêu Thần Lôi Quyết','DiHe','[\"Loi\"]','Dia','Trung',9,'{\"atk\": 60, \"matk\": 90, \"mdef\": 50, \"ti_le_gay_te_liet\": 5, \"ti_le_thanh_cong_do_kiep\": 3}',3,NULL,'Lôi hệ cao cấp, lôi kiếp huy hoàng'),(24,'Hỗn Độn Lôi Kinh','DiHe','[\"Loi\"]','Thien','Trung',9,'{\"atk\": 150, \"matk\": 200, \"mdef\": 80, \"ti_le_gay_te_liet\": 6, \"ti_le_thanh_cong_do_kiep\": 5}',4,NULL,'Lôi hệ đỉnh cao, hỗn độn thần lôi, Sấm sét bản nguyên'),(25,'Hàn Băng Chi Tức','DiHe','[\"Bang\"]','Hoang','Trung',9,'{\"atk\": 8, \"def\": 8, \"matk\": 20, \"mdef\": 20, \"ti_le_gay_dong_bang\": 2}',1,NULL,'Băng hệ công pháp cơ bản, hàn băng chi lực'),(26,'Huyền Băng Kinh','DiHe','[\"Bang\"]','Huyen','Trung',9,'{\"atk\": 20, \"def\": 20, \"matk\": 30, \"mdef\": 40, \"ti_le_gay_dong_bang\": 2.5}',2,NULL,'Băng hệ trung cấp, huyền băng chi khí'),(27,'Vạn Niên Băng Phách','DiHe','[\"Bang\"]','Dia','Trung',9,'{\"atk\": 50, \"def\": 50, \"matk\": 70, \"mdef\": 150, \"ti_le_gay_dong_bang\": 3}',3,NULL,'Băng hệ cao cấp, vạn niên băng phách'),(28,'Cửu U Băng Kinh','DiHe','[\"Bang\", \"Am\"]','Thien','Trung',9,'{\"atk\": 120, \"def\": 120, \"matk\": 120, \"mdef\": 180, \"ti_le_xuyen_phep\": 7, \"ti_le_gay_dong_bang\": 4}',4,NULL,'Băng hệ đỉnh cao, cửu u cực hàn, băng phong linh hồn'),(29,'Phong Hành Quyết','DiHe','[\"Phong\"]','Hoang','Trung',9,'{\"ti_le_ne\": 2.5, \"ti_le_gay_mu\": 2, \"giam_hoi_chieu\": 2}',1,NULL,'Phong hệ công pháp cơ bản, phong hành vô ảnh'),(30,'Cương Phong Kinh','DiHe','[\"Phong\"]','Huyen','Trung',9,'{\"ti_le_ne\": 3, \"ti_le_gay_mu\": 4, \"ti_le_ngo_dao\": 0.5, \"giam_hoi_chieu\": 2.5}',2,NULL,'Phong hệ trung cấp, cương phong chi lực'),(31,'Thiên Cương Phong Pháp','DiHe','[\"Phong\"]','Dia','Trung',9,'{\"ti_le_ne\": 3.5, \"ti_le_gay_mu\": 7, \"ti_le_ngo_dao\": 0.8, \"giam_hoi_chieu\": 2.7}',3,NULL,'Phong hệ cao cấp, thiên phong chi uy'),(32,'Hậu Thiên Dịch Số','DiHe','[\"Phong\", \"Thuy\"]','Thien','Trung',9,'{\"ti_le_ne\": 4, \"ti_le_gay_mu\": 12, \"ti_le_ngo_dao\": 1.2, \"giam_hoi_chieu\": 4}',4,NULL,'Phong hệ đỉnh cao, tính toán thiên cơ, cảm ngộ hồng trần'),(33,'Dương Quang Quyết','DiHe','[\"Duong\"]','Hoang','Trung',9,'{\"atk\": 10, \"def\": 10, \"matk\": 30, \"mdef\": 10, \"hp_max\": 60, \"mp_max\": 60, \"ti_le_kich_hoat_hoi_hp\": 2.5}',1,NULL,'Dương hệ công pháp cơ bản, quang minh chi lực'),(34,'Thái Dương Quan Tưởng Đồ','DiHe','[\"Duong\"]','Huyen','Trung',9,'{\"atk\": 40, \"def\": 20, \"matk\": 30, \"mdef\": 20, \"hp_max\": 150, \"mp_max\": 120, \"ti_le_ngo_dao\": 0.5, \"ti_le_kich_hoat_hoi_hp\": 4}',2,NULL,'Dương hệ trung cấp, thái dương chi quang'),(35,'Cửu Dương Luyện Thiên Quyết','DiHe','[\"Duong\"]','Dia','Trung',9,'{\"atk\": 100, \"def\": 70, \"matk\": 80, \"mdef\": 80, \"hp_max\": 400, \"mp_max\": 300, \"ti_le_ngo_dao\": 0.8, \"ti_le_kich_hoat_hoi_hp\": 7}',3,NULL,'Dương hệ cao cấp, cửu dương thần kinh'),(36,'Đại Nhật Thần Mộc Pháp','DiHe','[\"Duong\", \"Moc\"]','Thien','Trung',9,'{\"atk\": 50, \"def\": 70, \"hp_max\": 1500, \"ti_le_kich_hoat_hoi_hp\": 12, \"hieu_ung_hoi_phuc_bonus\": 10}',4,NULL,'Dương hệ đỉnh cao, Phù Tang tiên thiên linh căn, bất tử bất diệt'),(37,'U Minh Tế Văn','DiHe','[\"Am\"]','Hoang','Trung',9,'{\"matk\": 20, \"mdef\": 10, \"ti_le_ne\": 3, \"ti_le_hut_mau\": 3, \"ti_le_xuyen_phep\": 3}',1,NULL,'Âm hệ công pháp cơ bản, u minh chi lực'),(38,'Thái Âm Kinh','DiHe','[\"Am\"]','Huyen','Trung',9,'{\"matk\": 50, \"mdef\": 20, \"ti_le_ne\": 4, \"ti_le_hut_mau\": 4, \"ti_le_xuyen_phep\": 5}',2,NULL,'Âm hệ trung cấp, thái âm linh lực'),(39,'Cửu Âm Chân Kinh','DiHe','[\"Am\"]','Dia','Trung',9,'{\"matk\": 100, \"mdef\": 50, \"ti_le_ne\": 4.4, \"ti_le_hut_mau\": 4.4, \"ti_le_xuyen_phep\": 7, \"ti_le_gay_roi_loan\": 4}',3,NULL,'Âm hệ cao cấp, cửu âm chân kinh'),(40,'Nguyệt Quế Quan Tưởng Đồ','DiHe','[\"Am\", \"Moc\"]','Thien','Trung',9,'{\"matk\": 200, \"mdef\": 300, \"ti_le_ne\": 2, \"ti_le_hut_mau\": 4, \"ti_le_xuyen_phep\": 10, \"ti_le_gay_roi_loan\": 6}',4,NULL,'Âm hệ đỉnh cao, Nguyệt Quế Tiên Thiên linh căn, Linh hồn bất hủ '),(41,'Bá Thể Quyết','LuyenThe',NULL,'Dia','Trung',9,'{\"atk\": 100, \"def\": 150, \"hp_max\": 300, \"khang_am\": 3, \"khang_hoa\": 3, \"khang_kim\": 3, \"khang_loi\": 3, \"khang_moc\": 3, \"khang_tho\": 3, \"khang_bang\": 3, \"khang_thuy\": 3, \"khang_duong\": 3, \"khang_phong\": 3, \"hieu_ung_hoi_phuc_bonus\": 20}',3,'{\"he_so\": 1.5, \"dieu_kien\": \"Duong\"}','Luyện thể công pháp, tăng chỉ số cơ bản, kháng nguyên tố, bonus hồi phục. Dương hệ +50%'),(42,'Thần Hồn Quyết','LuyenHon',NULL,'Dia','Trung',9,'{\"atk\": 25, \"def\": 15, \"matk\": 100, \"mdef\": 80, \"hp_max\": 100, \"ti_le_chi_mang\": 3, \"ti_le_gay_roi_loan\": 5, \"sat_thuong_chi_mang\": 20}',3,'{\"he_so\": 1.5, \"dieu_kien\": \"Am\"}','Luyện hồn công pháp, tăng mạnh matk/mdef, chí mạng và rối loạn. Âm hệ +50%');
/*!40000 ALTER TABLE `tmpl_cong_phap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_dan_duoc`
--

DROP TABLE IF EXISTS `tmpl_dan_duoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_dan_duoc` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ten` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pham_cap` enum('Pham','Linh','Bao','Tien','Than') COLLATE utf8mb4_unicode_ci NOT NULL,
  `loai` enum('HoiPhuc','DotPha','TangTuVi','Buff','Doc','Ho Tro Dot Pha') COLLATE utf8mb4_unicode_ci NOT NULL,
  `effect` json NOT NULL,
  `yeu_cau_nghe_cap` tinyint unsigned NOT NULL DEFAULT '1',
  `ti_le_dot_pha_bonus` decimal(5,2) NOT NULL DEFAULT '0.00',
  `exp_bonus` bigint unsigned NOT NULL DEFAULT '0',
  `tu_vi_bonus` bigint unsigned NOT NULL DEFAULT '0',
  `thoi_gian_hieu_luc` int unsigned NOT NULL DEFAULT '0',
  `gioi_han_moi_canh_gioi` tinyint NOT NULL DEFAULT '0',
  `ap_dung_canh_gioi_id` tinyint unsigned DEFAULT NULL,
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dan_duoc_ten` (`ten`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_dan_duoc`
--

LOCK TABLES `tmpl_dan_duoc` WRITE;
/*!40000 ALTER TABLE `tmpl_dan_duoc` DISABLE KEYS */;
INSERT INTO `tmpl_dan_duoc` VALUES (1,'Hồi Khí Đan','Pham','HoiPhuc','{\"hp\": 200}',1,0.00,0,0,0,0,NULL,'Hồi phục 200 HP tức thời'),(2,'Hồi Linh Đan','Pham','HoiPhuc','{\"mp\": 100}',1,0.00,0,0,0,0,NULL,'Hồi phục 100 MP tức thời'),(3,'Hồi Khí Đan - Trung','Linh','HoiPhuc','{\"hp\": 1000}',2,0.00,0,0,0,0,NULL,'Hồi phục 1000 HP tức thời'),(4,'Hồi Linh Đan - Trung','Linh','HoiPhuc','{\"mp\": 500}',2,0.00,0,0,0,0,NULL,'Hồi phục 500 MP tức thời'),(5,'Song Hồi Đan','Linh','HoiPhuc','{\"hp\": 500, \"mp\": 300}',3,0.00,0,0,0,0,NULL,'Hồi phục 500 HP + 300 MP tức thời'),(6,'Đại Hồi Khí Đan','Bao','HoiPhuc','{\"hp\": 5000}',5,0.00,0,0,0,0,NULL,'Hồi phục 5000 HP tức thời'),(7,'Đại Hồi Linh Đan','Bao','HoiPhuc','{\"mp\": 3000}',5,0.00,0,0,0,0,NULL,'Hồi phục 3000 MP tức thời'),(8,'Thập Toàn Đại Bổ Đan','Tien','HoiPhuc','{\"hp\": 99999, \"mp\": 99999}',7,0.00,0,0,0,0,NULL,'Hồi phục toàn bộ HP và MP'),(9,'Hồi Xuân Đan','Pham','HoiPhuc','{\"turns\": 5, \"hp_per_turn\": 50}',1,0.00,0,0,0,0,NULL,'Hồi 50 HP mỗi lượt trong 5 lượt (tổng 250 HP)'),(10,'Trường Sinh Đan','Linh','HoiPhuc','{\"turns\": 10, \"hp_per_turn\": 150}',3,0.00,0,0,0,0,NULL,'Hồi 150 HP mỗi lượt trong 10 lượt (tổng 1500 HP)'),(11,'Linh Lực Đan','Linh','HoiPhuc','{\"turns\": 10, \"mp_per_turn\": 80}',3,0.00,0,0,0,0,NULL,'Hồi 80 MP mỗi lượt trong 10 lượt (tổng 800 MP)'),(12,'Song Sinh Đan','Bao','HoiPhuc','{\"turns\": 10, \"hp_per_turn\": 300, \"mp_per_turn\": 150}',5,0.00,0,0,0,0,NULL,'Hồi 300 HP + 150 MP mỗi lượt trong 10 lượt'),(13,'Sinh Sinh Bất Tức Đan','Tien','HoiPhuc','{\"turns\": 20, \"hp_per_turn\": 1000, \"mp_per_turn\": 500}',7,0.00,0,0,0,0,NULL,'Hồi 1000 HP + 500 MP mỗi lượt trong 20 lượt'),(14,'Hồi Sinh Đan','Bao','HoiPhuc','{\"hp\": 2000, \"turns\": 10, \"hp_per_turn\": 100}',5,0.00,0,0,0,0,NULL,'Hồi ngay 2000 HP + 100 HP mỗi lượt trong 10 lượt'),(15,'Trúc Cơ Đan','Linh','DotPha','{}',2,15.00,0,0,3600,0,1,'Dùng khi đột phá Luyện Khí → Trúc Cơ. +15% tỉ lệ trong 1 giờ'),(16,'Trúc Cơ Đan - Thượng','Bao','DotPha','{}',4,25.00,0,0,1800,0,1,'Dùng khi đột phá Luyện Khí → Trúc Cơ. +25% tỉ lệ trong 30 phút'),(17,'Cửu Kim Đan','Linh','DotPha','{}',3,15.00,0,0,3600,0,2,'Dùng khi đột phá Trúc Cơ → Kim Đan. +15% tỉ lệ trong 1 giờ'),(18,'Cửu Chuyển Kim Đan','Bao','DotPha','{}',5,25.00,0,0,1800,0,2,'Dùng khi đột phá Trúc Cơ → Kim Đan. +25% tỉ lệ trong 30 phút'),(19,'Nguyên Anh Đan','Bao','DotPha','{}',4,20.00,0,0,3600,0,3,'Dùng khi đột phá Kim Đan → Nguyên Anh. +20% tỉ lệ trong 1 giờ'),(20,'Nguyên Anh Đan - Thượng','Tien','DotPha','{}',6,30.00,0,0,1800,0,3,'Dùng khi đột phá Kim Đan → Nguyên Anh. +30% tỉ lệ trong 30 phút'),(21,'Hóa Thần Đan','Bao','DotPha','{}',5,20.00,0,0,3600,0,4,'Dùng khi đột phá Nguyên Anh → Hóa Thần. +20% tỉ lệ trong 1 giờ'),(22,'Hóa Thần Đan - Thượng','Tien','DotPha','{}',7,35.00,0,0,1800,0,4,'Dùng khi đột phá Nguyên Anh → Hóa Thần. +35% tỉ lệ trong 30 phút'),(23,'Luyện Hư Đan','Bao','DotPha','{}',6,25.00,0,0,3600,0,5,'Dùng khi đột phá Hóa Thần → Luyện Hư. +25% tỉ lệ trong 1 giờ'),(24,'Luyện Hư Đan - Thượng','Tien','DotPha','{}',8,40.00,0,0,1800,0,5,'Dùng khi đột phá Hóa Thần → Luyện Hư. +40% tỉ lệ trong 30 phút'),(25,'Hợp Thể Đan','Tien','DotPha','{}',7,25.00,0,0,3600,0,6,'Dùng khi đột phá Luyện Hư → Hợp Thể. +25% tỉ lệ trong 1 giờ'),(26,'Hợp Thể Đan - Thượng','Than','DotPha','{}',9,45.00,0,0,1800,0,6,'Dùng khi đột phá Luyện Hư → Hợp Thể. +45% tỉ lệ trong 30 phút'),(27,'Đại Thừa Đan','Tien','DotPha','{}',7,30.00,0,0,3600,0,7,'Dùng khi đột phá Hợp Thể → Đại Thừa. +30% tỉ lệ trong 1 giờ'),(28,'Đại Thừa Đan - Thượng','Than','DotPha','{}',9,50.00,0,0,1800,0,7,'Dùng khi đột phá Hợp Thể → Đại Thừa. +50% tỉ lệ trong 30 phút'),(29,'Độ Kiếp Đan','Tien','DotPha','{}',8,30.00,0,0,3600,0,8,'Dùng khi đột phá Đại Thừa → Độ Kiếp. +30% tỉ lệ trong 1 giờ'),(30,'Độ Kiếp Đan - Thượng','Than','DotPha','{}',9,55.00,0,0,1800,0,8,'Dùng khi đột phá Đại Thừa → Độ Kiếp. +55% tỉ lệ trong 30 phút'),(31,'Tiên Nhân Đan','Than','DotPha','{}',9,40.00,0,0,3600,0,9,'Dùng khi đột phá Độ Kiếp → Tiên Nhân. +40% tỉ lệ trong 1 giờ'),(32,'Tiên Nhân Đan - Thượng','Than','DotPha','{}',9,60.00,0,0,1800,1,9,'Dùng khi đột phá Độ Kiếp → Tiên Nhân. +60% tỉ lệ trong 30 phút. Chỉ 1 lần duy nhất'),(33,'Phá Cảnh Đan','Bao','DotPha','{}',5,30.00,0,0,1800,1,NULL,'Đan đặc biệt, dùng cho MỌI cảnh giới. +30% tỉ lệ. Chỉ 1 lần/cảnh giới, tác dụng trong 30 phút'),(34,'Tụ Linh Đan','Pham','TangTuVi','{\"tu_vi\": 80}',1,0.00,80,80,0,0,NULL,'Tăng 80 tu vi. Đan cơ bản cho tân thủ'),(35,'Ngưng Nguyên Đan','Linh','TangTuVi','{\"tu_vi\": 200}',2,0.00,200,200,0,0,NULL,'Tăng 200 tu vi. Đan trung cấp cho tu sĩ Trúc Cơ'),(36,'Kim Đan Chi Diệu','Linh','TangTuVi','{\"tu_vi\": 2000}',3,0.00,2000,2000,0,0,NULL,'Tăng 2000 tu vi ngay lập tức'),(37,'Thông Thiên Đan','Bao','TangTuVi','{\"tu_vi\": 10000}',5,0.00,10000,10000,0,0,NULL,'Tăng 10000 tu vi. Đan cao cấp cho tu sĩ Kim Đan'),(38,'Đạo Nguyên Đan','Tien','TangTuVi','{\"tu_vi\": 200000}',7,0.00,200000,200000,0,0,NULL,'Tăng 200000 tu vi. Đan tiên phẩm cho đại năng'),(39,'Thiên Kiếp Đan','Tien','TangTuVi','{\"tu_vi\": 500000}',7,0.00,500000,500000,0,0,NULL,'Tăng 500000 tu vi ngay lập tức'),(40,'Sáng Thế Đan','Than','TangTuVi','{\"tu_vi\": 2000000}',9,0.00,2000000,2000000,0,0,NULL,'Tăng 2000000 tu vi. Đan thần phẩm, cực kỳ hiếm'),(41,'Hỗn Độn Đan','Than','TangTuVi','{\"tu_vi\": 5000000}',9,0.00,5000000,5000000,0,0,NULL,'Tăng 5000000 tu vi ngay lập tức'),(42,'Trường Thọ Đan','Bao','Buff','{\"hp_max\": 1000}',4,0.00,0,0,3600,0,NULL,'Tăng 1000 HP max trong 1 giờ'),(43,'Bạo Khí Đan','Bao','Buff','{\"atk\": 150}',4,0.00,0,0,1800,0,NULL,'Tăng 150 atk trong 30 phút'),(44,'Hộ Thể Đan','Linh','Buff','{\"def\": 30}',2,0.00,0,0,1800,0,NULL,'Tăng 30 def trong 30 phút'),(45,'Tinh Khuyết Đan','Bao','Buff','{\"tinh_khiet\": 10}',4,0.00,0,0,0,0,NULL,'Tăng 10% độ tinh khiết cho linh căn ngẫu nhiên'),(46,'Huyết Nguyên Đan','Linh','Buff','{\"hp_max_pct\": 10}',3,0.00,0,0,1800,0,NULL,'Tăng 10% HP tối đa trong 30 phút'),(47,'Đại Huyết Nguyên Đan','Bao','Buff','{\"hp_max_pct\": 25}',5,0.00,0,0,3600,0,NULL,'Tăng 25% HP tối đa trong 1 giờ'),(48,'Linh Nguyên Đan','Linh','Buff','{\"mp_max_pct\": 10}',3,0.00,0,0,1800,0,NULL,'Tăng 10% MP tối đa trong 30 phút'),(49,'Đại Linh Nguyên Đan','Bao','Buff','{\"mp_max_pct\": 25}',5,0.00,0,0,3600,0,NULL,'Tăng 25% MP tối đa trong 1 giờ'),(50,'Cuồng Lực Đan','Linh','Buff','{\"atk_pct\": 15}',3,0.00,0,0,1800,0,NULL,'Tăng 15% công kích trong 30 phút'),(51,'Đại Cuồng Lực Đan','Bao','Buff','{\"atk_pct\": 30}',5,0.00,0,0,3600,0,NULL,'Tăng 30% công kích trong 1 giờ'),(52,'Kim Cương Đan','Linh','Buff','{\"def_pct\": 15}',3,0.00,0,0,1800,0,NULL,'Tăng 15% phòng ngự trong 30 phút'),(53,'Đại Kim Cương Đan','Bao','Buff','{\"def_pct\": 30}',5,0.00,0,0,3600,0,NULL,'Tăng 30% phòng ngự trong 1 giờ'),(54,'Pháp Nguyên Đan','Linh','Buff','{\"matk_pct\": 15}',3,0.00,0,0,1800,0,NULL,'Tăng 15% công kích phép trong 30 phút'),(55,'Đại Pháp Nguyên Đan','Bao','Buff','{\"matk_pct\": 30}',5,0.00,0,0,3600,0,NULL,'Tăng 30% công kích phép trong 1 giờ'),(56,'Hộ Pháp Đan','Linh','Buff','{\"mdef_pct\": 15}',3,0.00,0,0,1800,0,NULL,'Tăng 15% phòng ngự phép trong 30 phút'),(57,'Đại Hộ Pháp Đan','Bao','Buff','{\"mdef_pct\": 30}',5,0.00,0,0,3600,0,NULL,'Tăng 30% phòng ngự phép trong 1 giờ'),(58,'Song Lực Đan','Bao','Buff','{\"atk_pct\": 15, \"def_pct\": 15}',5,0.00,0,0,1800,0,NULL,'Tăng 15% atk + 15% def trong 30 phút'),(59,'Song Pháp Đan','Bao','Buff','{\"matk_pct\": 15, \"mdef_pct\": 15}',5,0.00,0,0,1800,0,NULL,'Tăng 15% matk + 15% mdef trong 30 phút'),(60,'Sinh Mệnh Đan','Bao','Buff','{\"hp_max_pct\": 15, \"mp_max_pct\": 15}',5,0.00,0,0,3600,0,NULL,'Tăng 15% HP + 15% MP tối đa trong 1 giờ'),(61,'Tứ Đại Đan','Tien','Buff','{\"atk_pct\": 20, \"def_pct\": 20, \"matk_pct\": 20, \"mdef_pct\": 20}',7,0.00,0,0,1800,0,NULL,'Tăng 20% atk/def/matk/mdef trong 30 phút'),(62,'Lục Đạo Đan','Tien','Buff','{\"atk_pct\": 15, \"def_pct\": 15, \"matk_pct\": 15, \"mdef_pct\": 15, \"hp_max_pct\": 15, \"mp_max_pct\": 15}',8,0.00,0,0,3600,0,NULL,'Tăng 15% toàn bộ 6 chỉ số trong 1 giờ'),(63,'Thiên Địa Đan','Than','Buff','{\"atk_pct\": 30, \"def_pct\": 30, \"matk_pct\": 30, \"mdef_pct\": 30, \"hp_max_pct\": 30, \"mp_max_pct\": 30}',9,0.00,0,0,3600,0,NULL,'Tăng 30% toàn bộ 6 chỉ số trong 1 giờ'),(64,'Huyết Chiến Đan','Bao','Buff','{\"atk\": 100, \"atk_pct\": 20}',5,0.00,0,0,1800,0,NULL,'Tăng 20% atk + 100 atk flat trong 30 phút'),(65,'Thiết Giáp Đan','Bao','Buff','{\"def\": 100, \"def_pct\": 20}',5,0.00,0,0,1800,0,NULL,'Tăng 20% def + 100 def flat trong 30 phút'),(66,'Toàn Năng Đan','Tien','Buff','{\"atk\": 50, \"def\": 50, \"atk_pct\": 15, \"def_pct\": 15}',7,0.00,0,0,3600,0,NULL,'Tăng 15% atk/def + 50 atk/def flat trong 1 giờ'),(67,'Cuồng Ma Đan','Linh','Buff','{\"turns\": 10, \"atk_pct\": 50, \"def_pct\": -30, \"hp_cost_per_turn_pct_hien_tai\": 3}',3,0.00,0,0,0,0,NULL,'Tăng 50% atk, giảm 30% def trong 10 lượt. Mất 3% HP hiện tại mỗi lượt'),(68,'Huyết Sát Đan','Bao','Buff','{\"turns\": 5, \"atk_pct\": 100, \"def_pct\": -50, \"matk_pct\": 100, \"mdef_pct\": -50, \"death_after_turns\": 7, \"hp_cost_per_turn_pct_hien_tai\": 10}',5,0.00,0,0,0,0,NULL,'Tăng 100% atk/matk, giảm 50% def/mdef trong 5 lượt. Mất 10% HP hiện tại/lượt. Sau 7 lượt HP về 0'),(69,'Thiên Ma Đan','Tien','Buff','{\"turns\": 10, \"atk_pct\": 150, \"def_pct\": 150, \"matk_pct\": 150, \"mdef_pct\": 150, \"stun_turns\": 3}',7,0.00,0,0,0,0,NULL,'Tăng 150% toàn bộ stat trong 10 lượt. Bị choáng 3 lượt đầu'),(70,'Tử Vong Đan','Bao','Buff','{\"turns\": 8, \"atk_pct\": 300, \"hp_max_pct\": -70}',5,0.00,0,0,0,0,NULL,'Tăng 300% atk nhưng giảm 70% HP max trong 8 lượt'),(71,'Nghịch Thiên Đan','Than','Buff','{\"turns\": 10, \"atk_pct\": 200, \"def_pct\": 200, \"exp_cost\": 2000000, \"matk_pct\": 200, \"mdef_pct\": 200, \"hp_max_pct\": 100, \"death_after_turns\": 10}',9,0.00,0,0,0,0,NULL,'Tăng 200% toàn bộ stat + 100% HP max trong 10 lượt. Mất 2000000 exp. Sau 10 lượt HP về 0'),(72,'Độc Xà Đan','Pham','Doc','{\"turns\": 3, \"target\": \"enemy\", \"ignore_def\": false, \"poison_dmg\": 50}',1,0.00,0,0,0,0,NULL,'Ném vào kẻ địch, gây 50 sát thương độc/lượt trong 3 lượt. Bị giảm bởi kháng phép'),(73,'Hắc Ám Đan','Linh','Doc','{\"turns\": 5, \"debuff\": {\"atk_pct\": -15}, \"target\": \"enemy\", \"ignore_def\": false, \"poison_dmg\": 200}',3,0.00,0,0,0,0,NULL,'Ném vào kẻ địch: 200 dmg độc/lượt + giảm 15% atk trong 5 lượt. Bị giảm bởi kháng phép'),(74,'Huyết Độc Đan','Linh','Doc','{\"turns\": 5, \"debuff\": {\"def_pct\": -20}, \"target\": \"enemy\", \"ignore_def\": false, \"poison_dmg\": 300}',4,0.00,0,0,0,0,NULL,'Ném vào kẻ địch: 300 dmg độc/lượt + giảm 20% def trong 5 lượt. Bị giảm bởi kháng phép'),(75,'Thi Vương Đan','Bao','Doc','{\"turns\": 10, \"debuff\": {\"atk_pct\": -30, \"def_pct\": -30}, \"target\": \"enemy\", \"ignore_def\": false, \"poison_dmg\": 1000}',6,0.00,0,0,0,0,NULL,'Ném vào kẻ địch: 1000 dmg độc/lượt + giảm 30% atk/def trong 10 lượt. Bị giảm bởi kháng phép'),(76,'Vạn Độc Đan','Tien','Doc','{\"turns\": 10, \"debuff\": {\"atk_pct\": -50, \"def_pct\": -50, \"matk_pct\": -50, \"mdef_pct\": -50}, \"target\": \"enemy\", \"ignore_def\": false, \"poison_dmg\": 5000}',8,0.00,0,0,0,0,NULL,'Ném vào kẻ địch: 5000 dmg độc/lượt + giảm 50% toàn bộ chỉ số trong 10 lượt. Bị giảm bởi kháng phép'),(77,'Độc Chuyển Đan','Linh','Doc','{\"turns\": 3, \"target\": \"enemy_pvp\", \"ignore_def\": false, \"poison_dmg\": 300}',3,0.00,0,0,0,0,NULL,'PvP: ném vào đối thủ gây 300 dmg độc/lượt trong 3 lượt. Bị giảm bởi kháng phép'),(78,'Huyết Chuyển Đan','Bao','Doc','{\"turns\": 5, \"target\": \"enemy_pvp\", \"ignore_def\": false, \"poison_dmg\": 1000}',5,0.00,0,0,0,0,NULL,'PvP: ném vào đối thủ gây 1000 dmg độc/lượt trong 5 lượt. Bị giảm bởi kháng phép'),(79,'Vạn Độc Chuyển Đan','Tien','Doc','{\"turns\": 10, \"debuff\": {\"atk_pct\": -40}, \"target\": \"enemy_pvp\", \"ignore_def\": true, \"poison_dmg\": 5000}',8,0.00,0,0,0,0,NULL,'PvP: 5000 dmg độc/lượt + giảm 40% atk đối thủ trong 10 lượt. BỎ QUA kháng phép'),(80,'Thiên Độc Đan','Than','Doc','{\"turns\": 5, \"debuff\": {\"atk_pct\": -50, \"def_pct\": -50}, \"target\": \"enemy_pvp\", \"ignore_def\": true, \"poison_dmg\": 20000}',9,0.00,0,0,0,0,NULL,'PvP: 20000 dmg độc/lượt + giảm 50% atk/def đối thủ trong 5 lượt. BỎ QUA kháng phép');
/*!40000 ALTER TABLE `tmpl_dan_duoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_dan_phuong`
--

DROP TABLE IF EXISTS `tmpl_dan_phuong`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_dan_phuong` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `dan_duoc_id` int unsigned NOT NULL,
  `linh_thao_id` int unsigned NOT NULL,
  `so_luong` smallint unsigned NOT NULL,
  `ti_le_thanh_cong_max` decimal(5,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dan_phuong` (`dan_duoc_id`,`linh_thao_id`),
  KEY `fk_dp_linh_thao` (`linh_thao_id`),
  CONSTRAINT `fk_dp_dan_duoc` FOREIGN KEY (`dan_duoc_id`) REFERENCES `tmpl_dan_duoc` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dp_linh_thao` FOREIGN KEY (`linh_thao_id`) REFERENCES `tmpl_linh_thao` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_dan_phuong`
--

LOCK TABLES `tmpl_dan_phuong` WRITE;
/*!40000 ALTER TABLE `tmpl_dan_phuong` DISABLE KEYS */;
INSERT INTO `tmpl_dan_phuong` VALUES (1,1,1,3,90.00),(2,1,3,2,90.00),(3,2,2,3,90.00),(4,2,4,2,90.00),(5,3,1,5,78.00),(6,3,6,3,78.00),(7,3,10,2,78.00),(8,4,2,5,78.00),(9,4,4,3,78.00),(10,4,9,2,78.00),(11,5,1,5,78.00),(12,5,2,5,78.00),(13,5,6,3,78.00),(14,9,5,3,90.00),(15,9,3,2,90.00),(16,10,1,5,78.00),(17,10,6,4,78.00),(18,10,10,3,78.00),(19,11,2,5,78.00),(20,11,9,4,78.00),(21,11,4,3,78.00),(22,12,6,6,66.00),(23,12,11,4,66.00),(24,12,14,3,66.00),(25,12,10,3,66.00),(26,13,11,4,54.00),(27,13,15,3,54.00),(28,13,17,5,54.00),(29,13,18,4,54.00),(30,13,14,2,54.00),(31,14,11,4,66.00),(32,14,12,4,66.00),(33,14,13,3,66.00),(34,14,14,1,66.00),(35,15,6,5,78.00),(36,15,7,3,78.00),(37,17,6,5,78.00),(38,17,8,3,78.00),(39,17,10,2,78.00),(40,19,11,5,66.00),(41,19,12,3,66.00),(42,19,14,3,66.00),(43,21,11,5,66.00),(44,21,13,3,66.00),(45,21,10,3,66.00),(46,23,12,5,66.00),(47,23,13,4,66.00),(48,23,14,3,66.00),(49,25,15,6,54.00),(50,25,17,5,54.00),(51,25,18,4,54.00),(52,25,14,3,54.00),(53,27,16,6,54.00),(54,27,17,5,54.00),(55,27,11,4,54.00),(56,27,18,4,54.00),(57,29,15,4,54.00),(58,29,16,3,54.00),(59,29,18,5,54.00),(60,29,17,5,54.00),(61,29,14,5,54.00),(62,31,19,5,42.00),(63,31,20,5,42.00),(64,31,15,5,42.00),(65,31,16,5,42.00),(66,31,17,5,42.00),(67,31,18,5,42.00),(68,31,11,5,42.00),(69,31,12,5,42.00),(70,31,13,5,42.00),(71,31,14,5,42.00),(72,34,1,3,90.00),(73,34,5,2,90.00),(74,35,2,4,78.00),(75,35,6,3,78.00),(76,36,1,5,78.00),(77,36,10,4,78.00),(78,36,7,3,78.00),(79,37,11,5,66.00),(80,37,14,4,66.00),(81,37,12,3,66.00),(82,38,15,6,54.00),(83,38,17,5,54.00),(84,38,16,4,54.00),(85,38,18,3,54.00),(86,39,15,2,54.00),(87,39,16,6,54.00),(88,39,18,5,54.00),(89,39,17,4,54.00),(90,39,14,5,54.00),(91,40,19,10,42.00),(92,40,20,10,42.00),(93,40,15,10,42.00),(94,40,16,10,42.00),(95,40,17,10,42.00),(96,40,18,10,42.00),(97,40,11,10,42.00),(98,40,12,10,42.00),(99,40,13,10,42.00),(100,40,14,10,42.00),(101,42,11,5,66.00),(102,42,14,4,66.00),(103,42,13,3,66.00),(104,43,12,5,66.00),(105,43,11,4,66.00),(106,43,10,3,66.00),(107,44,6,4,78.00),(108,44,8,3,78.00),(109,46,6,4,78.00),(110,46,8,3,78.00),(111,46,10,2,78.00),(112,48,9,4,78.00),(113,48,6,3,78.00),(114,48,10,2,78.00),(115,50,8,4,78.00),(116,50,7,3,78.00),(117,50,10,2,78.00),(118,52,6,5,78.00),(119,52,7,3,78.00),(120,52,8,2,78.00),(121,54,9,5,78.00),(122,54,6,3,78.00),(123,54,10,2,78.00),(124,56,6,5,78.00),(125,56,9,3,78.00),(126,56,7,2,78.00),(127,58,11,5,66.00),(128,58,12,4,66.00),(129,58,13,3,66.00),(130,58,14,3,66.00),(131,59,13,5,66.00),(132,59,14,4,66.00),(133,59,11,3,66.00),(134,59,12,3,66.00),(135,60,11,6,66.00),(136,60,14,5,66.00),(137,60,13,4,66.00),(138,60,12,3,66.00);
/*!40000 ALTER TABLE `tmpl_dan_phuong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_dao_cu`
--

DROP TABLE IF EXISTS `tmpl_dao_cu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_dao_cu` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loai` enum('DotPhaLinhCan','TangTinhKhiet','TangTiLeDotPha','Khac') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pham_cap` enum('Pham','Linh','Bao','Tien','Than') COLLATE utf8mb4_unicode_ci NOT NULL,
  `he` enum('Kim','Moc','Thuy','Hoa','Tho','Loi','Bang','Phong','Duong','Am') COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Hệ của đạo cụ (NULL = dùng cho mọi hệ)',
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  `effect` json NOT NULL COMMENT 'VD: {"ti_le_bonus":25} hoặc {"tinh_khiet":10}',
  `co_the_mua_premium` tinyint NOT NULL DEFAULT '0' COMMENT '1 = có bán trong shop tiên ngọc',
  `gia_tien_ngoc` int unsigned NOT NULL DEFAULT '0' COMMENT 'Giá mua bằng tiên ngọc',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `ngay_tao` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dao_cu_code` (`code`),
  KEY `idx_dao_cu_loai` (`loai`,`pham_cap`),
  CONSTRAINT `chk_dao_cu_active` CHECK ((`is_active` in (0,1))),
  CONSTRAINT `chk_dao_cu_premium` CHECK ((`co_the_mua_premium` in (0,1)))
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Đạo cụ đặc biệt: đột phá linh căn, tăng tinh khiết, buff...';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_dao_cu`
--

LOCK TABLES `tmpl_dao_cu` WRITE;
/*!40000 ALTER TABLE `tmpl_dao_cu` DISABLE KEYS */;
INSERT INTO `tmpl_dao_cu` VALUES (6,'tang_tinh_khiet_nho','Linh Dịch - Nhỏ','TangTinhKhiet','Pham',NULL,'Tăng 10% độ tinh khiết cho 1 linh căn. Drop từ event','{\"tinh_khiet\": 10}',0,0,1,'2026-09-12 17:54:55'),(7,'tang_tinh_khiet_lon','Linh Dịch - Lớn','TangTinhKhiet','Linh',NULL,'Tăng 25% độ tinh khiết. Mua tiên ngọc','{\"tinh_khiet\": 25}',1,300,1,'2026-09-12 17:54:55'),(8,'tang_tinh_khiet_cuc','Linh Dịch - Cực Phẩm','TangTinhKhiet','Bao',NULL,'Tăng 50% độ tinh khiết. Mua tiên ngọc','{\"tinh_khiet\": 50}',1,800,1,'2026-09-12 17:54:55'),(13,'tinh_khiet_kim','Tiên Linh Thạch - Kim','TangTinhKhiet','Pham','Kim','Tăng độ tinh khiết cho linh căn Kim hệ','{}',1,399,1,'2026-09-13 22:04:16'),(14,'tinh_khiet_moc','Tiên Linh Thạch - Mộc','TangTinhKhiet','Pham','Moc','Tăng độ tinh khiết cho linh căn Mộc hệ','{}',1,149,1,'2026-09-13 22:04:16'),(15,'tinh_khiet_thuy','Tiên Linh Thạch - Thủy','TangTinhKhiet','Pham','Thuy','Tăng độ tinh khiết cho linh căn Thủy hệ','{}',1,149,1,'2026-09-13 22:04:16'),(16,'tinh_khiet_hoa','Tiên Linh Thạch - Hỏa','TangTinhKhiet','Pham','Hoa','Tăng độ tinh khiết cho linh căn Hỏa hệ','{}',1,149,1,'2026-09-13 22:04:16'),(17,'tinh_khiet_tho','Tiên Linh Thạch - Thổ','TangTinhKhiet','Pham','Tho','Tăng độ tinh khiết cho linh căn Thổ hệ','{}',1,149,1,'2026-09-13 22:04:16'),(18,'tinh_khiet_loi','Tiên Linh Thạch - Lôi','TangTinhKhiet','Pham','Loi','Tăng độ tinh khiết cho linh căn Lôi hệ (dị hệ)','{}',1,299,1,'2026-09-13 22:04:16'),(19,'tinh_khiet_bang','Tiên Linh Thạch - Băng','TangTinhKhiet','Pham','Bang','Tăng độ tinh khiết cho linh căn Băng hệ (dị hệ)','{}',1,299,1,'2026-09-13 22:04:16'),(20,'tinh_khiet_phong','Tiên Linh Thạch - Phong','TangTinhKhiet','Pham','Phong','Tăng độ tinh khiết cho linh căn Phong hệ (dị hệ)','{}',1,299,1,'2026-09-13 22:04:16'),(21,'tinh_khiet_duong','Tiên Linh Thạch - Dương','TangTinhKhiet','Pham','Duong','Tăng độ tinh khiết cho linh căn Dương hệ (đặc biệt)','{}',1,499,1,'2026-09-13 22:04:16'),(22,'tinh_khiet_am','Tiên Linh Thạch - Âm','TangTinhKhiet','Pham','Am','Tăng độ tinh khiết cho linh căn Âm hệ (đặc biệt)','{}',1,499,1,'2026-09-13 22:04:16'),(23,'dot_pha_ha','Đan Đột Phá Linh Căn - Hạ phẩm','DotPhaLinhCan','Pham',NULL,'Đột phá linh căn Hạ → Trung (100%)','{}',1,10,1,'2026-09-15 08:20:50'),(24,'dot_pha_trung','Đan Đột Phá Linh Căn - Trung phẩm','DotPhaLinhCan','Linh',NULL,'Đột phá linh căn Trung → Thượng (100%)','{}',1,99,1,'2026-09-15 08:20:50'),(25,'dot_pha_thuong','Đan Đột Phá Linh Căn - Thượng phẩm','DotPhaLinhCan','Bao',NULL,'Đột phá linh căn Thượng → Cực (100%)','{}',1,199,1,'2026-09-15 08:20:50'),(26,'dot_pha_cuc','Đan Đột Phá Linh Căn - Cực phẩm','DotPhaLinhCan','Tien',NULL,'Đột phá linh căn Cực → Tiên (100%)','{}',1,299,1,'2026-09-15 08:20:50'),(27,'tang_ti_le_dot_pha_pham','Đan Tăng Tỉ Lệ - Phàm','TangTiLeDotPha','Pham',NULL,'Tăng 10% tỉ lệ đột phá (mọi phẩm cấp)','{\"ti_le_bonus\": 10}',0,0,1,'2026-09-15 08:20:50'),(28,'tang_ti_le_dot_pha_linh','Đan Tăng Tỉ Lệ - Linh','TangTiLeDotPha','Linh',NULL,'Tăng 25% tỉ lệ đột phá (mọi phẩm cấp)','{\"ti_le_bonus\": 25}',0,0,1,'2026-09-15 08:20:50'),(29,'tang_ti_le_dot_pha_bao','Đan Tăng Tỉ Lệ - Bảo','TangTiLeDotPha','Bao',NULL,'Tăng 50% tỉ lệ đột phá (mọi phẩm cấp)','{\"ti_le_bonus\": 50}',0,0,1,'2026-09-15 08:20:50'),(30,'tang_ti_le_dot_pha_tien','Đan Tăng Tỉ Lệ - Tiên','TangTiLeDotPha','Tien',NULL,'Tăng 75% tỉ lệ đột phá (mọi phẩm cấp)','{\"ti_le_bonus\": 75}',0,0,1,'2026-09-15 08:20:50'),(31,'tang_ti_le_dot_pha_than','Đan Tăng Tỉ Lệ - Thần','TangTiLeDotPha','Than',NULL,'Tăng 100% tỉ lệ đột phá (mọi phẩm cấp)','{\"ti_le_bonus\": 100}',0,0,1,'2026-09-15 08:20:50');
/*!40000 ALTER TABLE `tmpl_dao_cu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_dia_diem`
--

DROP TABLE IF EXISTS `tmpl_dia_diem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_dia_diem` (
  `id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  `he_so_linh_thach` decimal(4,2) NOT NULL DEFAULT '1.00',
  `he_so_exp` decimal(4,2) NOT NULL DEFAULT '1.00',
  `he_so_linh_thao` decimal(4,2) NOT NULL DEFAULT '1.00',
  `he_so_khoang_thach` decimal(4,2) NOT NULL DEFAULT '1.00',
  `he_so_dan_phuong` decimal(4,2) NOT NULL DEFAULT '1.00',
  `is_active` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dia_diem_code` (`code`),
  UNIQUE KEY `uk_dia_diem_ten` (`ten`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_dia_diem`
--

LOCK TABLES `tmpl_dia_diem` WRITE;
/*!40000 ALTER TABLE `tmpl_dia_diem` DISABLE KEYS */;
INSERT INTO `tmpl_dia_diem` VALUES (1,'van_tham','Vân Thâm Bất Tri Xứ','Nơi tiên nhân ẩn cư, linh khí dồi dào, yên bình',1.20,1.50,1.30,0.50,0.50,1),(2,'loan_tang','Loạn Táng Cương','Nghĩa địa hỗn loạn, tà khí ngập trời, nhiều nguy hiểm',1.50,1.00,0.80,0.50,0.30,1),(3,'bo_de','Bồ Đề Tự','Chùa cổ thanh tịnh, linh khí ôn hòa, tốt cho tu luyện',1.00,1.80,1.00,0.30,0.50,1),(4,'cho_quy','Chợ Quỷ','Nơi giao dịch của quỷ, đầy rẫy cơ duyên và cạm bẫy',2.00,0.80,1.20,1.50,2.50,1),(5,'thanh_tinh','Thanh Tĩnh Phong','Đỉnh núi thanh tĩnh, linh khí tinh khiết, tốt cho tu luyện',0.80,2.00,1.50,0.30,0.30,1),(6,'vo_gian','Vực Thẳm Vô Gian','Vực sâu vạn trượng, đầy rẫy yêu thú và tà tu, nguy hiểm nhưng nhiều cơ duyên',1.80,1.50,1.50,2.50,2.00,1);
/*!40000 ALTER TABLE `tmpl_dia_diem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_dia_diem_su_kien`
--

DROP TABLE IF EXISTS `tmpl_dia_diem_su_kien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_dia_diem_su_kien` (
  `dia_diem_id` tinyint unsigned NOT NULL,
  `su_kien_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trong_so` smallint unsigned NOT NULL DEFAULT '100',
  PRIMARY KEY (`dia_diem_id`,`su_kien_code`),
  CONSTRAINT `fk_ddsk_dia_diem` FOREIGN KEY (`dia_diem_id`) REFERENCES `tmpl_dia_diem` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_dia_diem_su_kien`
--

LOCK TABLES `tmpl_dia_diem_su_kien` WRITE;
/*!40000 ALTER TABLE `tmpl_dia_diem_su_kien` DISABLE KEYS */;
INSERT INTO `tmpl_dia_diem_su_kien` VALUES (1,'binh_yen',60),(1,'dan_phuong',10),(1,'exp_tuvi',100),(1,'khoang_thach',30),(1,'ky_ngo',10),(1,'linh_thach',100),(1,'linh_thao',120),(1,'sap_bay',20),(1,'ta_tu',10),(1,'thuong_nhan',10),(1,'yeu_thu',20),(2,'binh_yen',30),(2,'dan_phuong',15),(2,'exp_tuvi',60),(2,'khoang_thach',40),(2,'ky_ngo',2),(2,'linh_thach',80),(2,'linh_thao',30),(2,'sap_bay',80),(2,'ta_tu',100),(2,'thuong_nhan',5),(2,'yeu_thu',100),(3,'binh_yen',80),(3,'dan_phuong',20),(3,'exp_tuvi',150),(3,'khoang_thach',20),(3,'ky_ngo',15),(3,'linh_thach',60),(3,'linh_thao',80),(3,'sap_bay',20),(3,'ta_tu',15),(3,'thuong_nhan',20),(3,'yeu_thu',20),(4,'binh_yen',20),(4,'dan_phuong',100),(4,'exp_tuvi',30),(4,'khoang_thach',80),(4,'ky_ngo',8),(4,'linh_thach',150),(4,'linh_thao',50),(4,'sap_bay',40),(4,'ta_tu',60),(4,'thuong_nhan',150),(4,'yeu_thu',30),(5,'binh_yen',100),(5,'dan_phuong',15),(5,'exp_tuvi',180),(5,'khoang_thach',15),(5,'ky_ngo',20),(5,'linh_thach',40),(5,'linh_thao',100),(5,'sap_bay',10),(5,'ta_tu',10),(5,'thuong_nhan',5),(5,'yeu_thu',15),(6,'binh_yen',10),(6,'dan_phuong',60),(6,'exp_tuvi',80),(6,'khoang_thach',120),(6,'ky_ngo',8),(6,'linh_thach',100),(6,'linh_thao',60),(6,'sap_bay',100),(6,'ta_tu',120),(6,'thuong_nhan',10),(6,'yeu_thu',150);
/*!40000 ALTER TABLE `tmpl_dia_diem_su_kien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_khoang_thach`
--

DROP TABLE IF EXISTS `tmpl_khoang_thach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_khoang_thach` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pham_cap` enum('Pham','Linh','Bao','Tien','Than') COLLATE utf8mb4_unicode_ci NOT NULL,
  `loai` enum('LuyenKhi','VePhu','CaHai') COLLATE utf8mb4_unicode_ci NOT NULL,
  `he` enum('Kim','Moc','Thuy','Hoa','Tho','Loi','Bang','Phong','Duong','Am') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gia_ban` int unsigned NOT NULL DEFAULT '0' COMMENT 'Giá bán cho hệ thống (linh thạch)',
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_khoang_thach_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_khoang_thach`
--

LOCK TABLES `tmpl_khoang_thach` WRITE;
/*!40000 ALTER TABLE `tmpl_khoang_thach` DISABLE KEYS */;
INSERT INTO `tmpl_khoang_thach` VALUES (1,'chu_sa_pham','Chu Sa - Phàm','Pham','VePhu',NULL,50,'Chu sa cơ bản, dùng vẽ phù lục'),(2,'chu_sa_linh','Chu Sa - Linh','Linh','VePhu',NULL,200,'Chu sa linh cấp'),(3,'chu_sa_bao','Chu Sa - Bảo','Bao','VePhu',NULL,800,'Chu sa bảo cấp'),(4,'chu_sa_tien','Chu Sa - Tiên','Tien','VePhu',NULL,3000,'Chu sa tiên cấp'),(5,'chu_sa_than','Chu Sa - Thần','Than','VePhu',NULL,10000,'Chu sa thần cấp'),(6,'huyen_thiet','Huyền Thiết','Pham','LuyenKhi','Kim',80,'Sắt huyền, rèn vũ khí cơ bản'),(7,'tinh_kim','Tinh Kim','Linh','LuyenKhi','Kim',300,'Kim loại tinh luyện'),(8,'tu_Kim','Tử Kim','Bao','LuyenKhi','Kim',1200,'Tử kim quý hiếm'),(9,'thien_ngoai_van_thach','Thiên ngoại vẫn thạch','Tien','LuyenKhi','Kim',8000,'Thiên thạch ngoài vũ trụ'),(10,'that_dieu_tinh_kim','Thất diệu tinh Kim','Than','LuyenKhi','Kim',50000,'Kim loại do đất trời nuôi dưỡng'),(11,'thanh_tung','Thanh Tùng Mộc','Pham','LuyenKhi','Moc',60,'Gỗ thanh tùng'),(12,'tu_dan_moc','Tử Đàn Mộc','Linh','LuyenKhi','Moc',250,'Gỗ tử đàn'),(13,'long_huyet_moc','Long Huyết Mộc','Bao','LuyenKhi','Moc',1000,'Gỗ long huyết'),(14,'phu_tang_moc','Phù Tang Mộc','Tien','LuyenKhi','Moc',5000,'Gỗ phù tang nơi kim ô thần điểu nghỉ'),(15,'kien_moc','Kiến Mộc','Than','LuyenKhi','Moc',20000,'Thần mộc sáng thế'),(16,'thuy_ngoc','Thủy Ngọc','Linh','LuyenKhi','Thuy',250,'Ngọc thủy hệ'),(17,'hoa_ngoc','Hỏa Ngọc','Linh','LuyenKhi','Hoa',250,'Ngọc hỏa hệ'),(18,'tho_ngoc','Thổ Ngọc','Linh','LuyenKhi','Tho',250,'Ngọc thổ hệ'),(19,'kim_ngoc','Kim Ngọc','Linh','LuyenKhi','Kim',250,'Ngọc kim hệ'),(20,'moc_ngoc','Mộc Ngọc','Linh','LuyenKhi','Moc',250,'Ngọc mộc hệ');
/*!40000 ALTER TABLE `tmpl_khoang_thach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_linh_can`
--

DROP TABLE IF EXISTS `tmpl_linh_can`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_linh_can` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `ten` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `he` enum('Kim','Moc','Thuy','Hoa','Tho','Loi','Bang','Phong','Duong','Am') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pham_cap` enum('Ha','Trung','Thuong','Cuc','Tien') COLLATE utf8mb4_unicode_ci NOT NULL,
  `he_so_bonus` decimal(5,2) NOT NULL DEFAULT '1.00',
  `ti_le_dot_pha_bonus` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '% cộng vào tỉ lệ đột phá khi linh căn active',
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_linh_can` (`ten`,`pham_cap`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_linh_can`
--

LOCK TABLES `tmpl_linh_can` WRITE;
/*!40000 ALTER TABLE `tmpl_linh_can` DISABLE KEYS */;
INSERT INTO `tmpl_linh_can` VALUES (1,'Kim Linh Căn - Hạ','Kim','Ha',0.80,0.00,'Kim hệ hạ phẩm, thiên phú kém'),(2,'Kim Linh Căn - Trung','Kim','Trung',1.00,1.00,'Kim hệ trung phẩm, thiên phú thường'),(3,'Kim Linh Căn - Thượng','Kim','Thuong',1.30,2.00,'Kim hệ thượng phẩm, thiên phú tốt'),(4,'Kim Linh Căn - Cực','Kim','Cuc',1.70,3.00,'Kim hệ cực phẩm, vạn người có một'),(5,'Kim Linh Căn - Tiên','Kim','Tien',2.50,5.00,'Kim hệ tiên phẩm, truyền thuyết'),(6,'Mộc Linh Căn - Hạ','Moc','Ha',0.80,0.00,'Mộc hệ hạ phẩm, thiên phú kém'),(7,'Mộc Linh Căn - Trung','Moc','Trung',1.00,1.00,'Mộc hệ trung phẩm, thiên phú thường'),(8,'Mộc Linh Căn - Thượng','Moc','Thuong',1.30,2.00,'Mộc hệ thượng phẩm, thiên phú tốt'),(9,'Mộc Linh Căn - Cực','Moc','Cuc',1.70,3.00,'Mộc hệ cực phẩm, vạn người có một'),(10,'Mộc Linh Căn - Tiên','Moc','Tien',2.50,5.00,'Mộc hệ tiên phẩm, truyền thuyết'),(11,'Thủy Linh Căn - Hạ','Thuy','Ha',0.80,0.00,'Thủy hệ hạ phẩm, thiên phú kém'),(12,'Thủy Linh Căn - Trung','Thuy','Trung',1.00,1.00,'Thủy hệ trung phẩm, thiên phú thường'),(13,'Thủy Linh Căn - Thượng','Thuy','Thuong',1.30,2.00,'Thủy hệ thượng phẩm, thiên phú tốt'),(14,'Thủy Linh Căn - Cực','Thuy','Cuc',1.70,3.00,'Thủy hệ cực phẩm, vạn người có một'),(15,'Thủy Linh Căn - Tiên','Thuy','Tien',2.50,5.00,'Thủy hệ tiên phẩm, truyền thuyết'),(16,'Hỏa Linh Căn - Hạ','Hoa','Ha',0.80,0.00,'Hỏa hệ hạ phẩm, thiên phú kém'),(17,'Hỏa Linh Căn - Trung','Hoa','Trung',1.00,1.00,'Hỏa hệ trung phẩm, thiên phú thường'),(18,'Hỏa Linh Căn - Thượng','Hoa','Thuong',1.30,2.00,'Hỏa hệ thượng phẩm, thiên phú tốt'),(19,'Hỏa Linh Căn - Cực','Hoa','Cuc',1.70,3.00,'Hỏa hệ cực phẩm, vạn người có một'),(20,'Hỏa Linh Căn - Tiên','Hoa','Tien',2.50,5.00,'Hỏa hệ tiên phẩm, truyền thuyết'),(21,'Thổ Linh Căn - Hạ','Tho','Ha',0.80,0.00,'Thổ hệ hạ phẩm, thiên phú kém'),(22,'Thổ Linh Căn - Trung','Tho','Trung',1.00,1.00,'Thổ hệ trung phẩm, thiên phú thường'),(23,'Thổ Linh Căn - Thượng','Tho','Thuong',1.30,2.00,'Thổ hệ thượng phẩm, thiên phú tốt'),(24,'Thổ Linh Căn - Cực','Tho','Cuc',1.70,3.00,'Thổ hệ cực phẩm, vạn người có một'),(25,'Thổ Linh Căn - Tiên','Tho','Tien',2.50,5.00,'Thổ hệ tiên phẩm, truyền thuyết'),(26,'Lôi Linh Căn - Hạ','Loi','Ha',0.90,0.00,'Lôi hệ hạ phẩm, hiếm hơn ngũ hành'),(27,'Lôi Linh Căn - Trung','Loi','Trung',1.20,2.00,'Lôi hệ trung phẩm, thiên lôi chi căn '),(28,'Lôi Linh Căn - Thượng','Loi','Thuong',1.60,3.00,'Lôi hệ thượng phẩm, thiên kiếp chi tử'),(29,'Lôi Linh Căn - Cực','Loi','Cuc',2.10,5.00,'Lôi hệ cực phẩm, nghịch thiên chi tư'),(30,'Lôi Linh Căn - Tiên','Loi','Tien',3.00,8.00,'Lôi hệ tiên phẩm, vạn cổ vô nhất'),(31,'Băng Linh Căn - Hạ','Bang','Ha',0.90,0.00,'Băng hệ hạ phẩm, hiếm hơn ngũ hành'),(32,'Băng Linh Căn - Trung','Bang','Trung',1.20,2.00,'Băng hệ trung phẩm, sương giá trăm năm'),(33,'Băng Linh Căn - Thượng','Bang','Thuong',1.60,3.00,'Băng hệ thượng phẩm, thiên niên hàn mạch'),(34,'Băng Linh Căn - Cực','Bang','Cuc',2.10,5.00,'Băng hệ cực phẩm, băng hà hàn cực'),(35,'Băng Linh Căn - Tiên','Bang','Tien',3.00,8.00,'Băng hệ tiên phẩm, băng phách vạn năm'),(36,'Phong Linh Căn - Hạ','Phong','Ha',0.90,0.00,'Phong hệ hạ phẩm, hiếm hơn ngũ hành'),(37,'Phong Linh Căn - Trung','Phong','Trung',1.20,2.00,'Phong hệ trung phẩm, thiên thanh chi phong'),(38,'Phong Linh Căn - Thượng','Phong','Thuong',1.60,3.00,'Phong hệ thượng phẩm, cương phong chi thể'),(39,'Phong Linh Căn - Cực','Phong','Cuc',2.10,5.00,'Phong hệ cực phẩm, phong bạo chi tử'),(40,'Phong Linh Căn - Tiên','Phong','Tien',3.00,8.00,'Phong hệ tiên phẩm, thái cổ cương phong'),(41,'Dương Linh Căn - Hạ','Duong','Ha',1.00,0.00,'Dương hệ hạ phẩm, hiếm hơn ngũ hành'),(42,'Dương Linh Căn - Trung','Duong','Trung',1.30,2.00,'Dương hệ trung phẩm, quang minh chi thể'),(43,'Dương Linh Căn - Thượng','Duong','Thuong',1.70,3.00,'Dương hệ thượng phẩm, đại nhật chi quang'),(44,'Dương Linh Căn - Cực','Duong','Cuc',2.20,5.00,'Dương hệ cực phẩm, thái dương chi thể'),(45,'Dương Linh Căn - Tiên','Duong','Tien',3.00,8.00,'Dương hệ tiên phẩm, cửu dương tuyệt mạch'),(46,'Âm Linh Căn - Hạ','Am','Ha',1.00,0.00,'Âm hệ hạ phẩm, hiếm hơn ngũ hành'),(47,'Âm Linh Căn - Trung','Am','Trung',1.30,2.00,'Âm hệ trung phẩm, u minh chi thể'),(48,'Âm Linh Căn - Thượng','Am','Thuong',1.70,3.00,'Âm hệ thượng phẩm, nguyệt hoa chi quang'),(49,'Âm Linh Căn - Cực','Am','Cuc',2.20,5.00,'Âm hệ cực phẩm, thái âm chi thể'),(50,'Âm Linh Căn - Tiên','Am','Tien',3.00,8.00,'Âm hệ tiên phẩm, cửu âm tuyệt mạch');
/*!40000 ALTER TABLE `tmpl_linh_can` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_linh_can_stat`
--

DROP TABLE IF EXISTS `tmpl_linh_can_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_linh_can_stat` (
  `linh_can_id` smallint unsigned NOT NULL,
  `stat_id` smallint unsigned NOT NULL,
  `gia_tri_bonus` decimal(10,4) NOT NULL,
  PRIMARY KEY (`linh_can_id`,`stat_id`),
  KEY `fk_lcs_stat` (`stat_id`),
  CONSTRAINT `fk_lcs_linh_can` FOREIGN KEY (`linh_can_id`) REFERENCES `tmpl_linh_can` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lcs_stat` FOREIGN KEY (`stat_id`) REFERENCES `tmpl_stat_type` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Mapping linh căn → stat bonus. Có thể âm (debuff).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_linh_can_stat`
--

LOCK TABLES `tmpl_linh_can_stat` WRITE;
/*!40000 ALTER TABLE `tmpl_linh_can_stat` DISABLE KEYS */;
INSERT INTO `tmpl_linh_can_stat` VALUES (1,11,6.0000),(1,14,3.7500),(1,15,3.7500),(1,21,-7.5000),(1,23,15.0000),(2,11,8.0000),(2,14,5.0000),(2,15,5.0000),(2,21,-10.0000),(2,23,20.0000),(3,11,10.6400),(3,14,6.6500),(3,15,6.6500),(3,21,-13.3000),(3,23,26.6000),(4,11,14.0000),(4,14,8.7500),(4,15,8.7500),(4,21,-17.5000),(4,23,35.0000),(5,11,20.0000),(5,14,12.5000),(5,15,12.5000),(5,21,-25.0000),(5,23,50.0000),(6,7,15.0000),(6,20,15.0000),(6,24,-7.5000),(6,44,15.0000),(7,7,20.0000),(7,20,20.0000),(7,24,-10.0000),(7,44,20.0000),(8,7,26.6000),(8,20,26.6000),(8,24,-13.3000),(8,44,26.6000),(9,7,35.0000),(9,20,35.0000),(9,24,-17.5000),(9,44,35.0000),(10,7,50.0000),(10,20,50.0000),(10,24,-25.0000),(10,44,50.0000),(11,8,15.0000),(11,17,3.7500),(11,23,-7.5000),(11,24,15.0000),(12,8,20.0000),(12,17,5.0000),(12,23,-10.0000),(12,24,20.0000),(13,8,26.6000),(13,17,6.6500),(13,23,-13.3000),(13,24,26.6000),(14,8,35.0000),(14,17,8.7500),(14,23,-17.5000),(14,24,35.0000),(15,8,50.0000),(15,17,12.5000),(15,23,-25.0000),(15,24,50.0000),(16,20,-7.5000),(16,22,15.0000),(16,36,11.2500),(16,37,22.5000),(17,20,-10.0000),(17,22,20.0000),(17,36,15.0000),(17,37,30.0000),(18,20,-13.3000),(18,22,26.6000),(18,36,19.9500),(18,37,39.9000),(19,20,-17.5000),(19,22,35.0000),(19,36,26.2500),(19,37,52.5000),(20,20,-25.0000),(20,22,50.0000),(20,36,37.5000),(20,37,75.0000),(21,1,60.0000),(21,4,15.0000),(21,18,7.5000),(21,21,15.0000),(21,22,-7.5000),(22,1,80.0000),(22,4,20.0000),(22,18,10.0000),(22,21,20.0000),(22,22,-10.0000),(23,1,106.4000),(23,4,26.6000),(23,18,13.3000),(23,21,26.6000),(23,22,-13.3000),(24,1,140.0000),(24,4,35.0000),(24,18,17.5000),(24,21,35.0000),(24,22,-17.5000),(25,1,200.0000),(25,4,50.0000),(25,18,25.0000),(25,21,50.0000),(25,22,-25.0000),(26,3,37.5000),(26,25,18.7500),(26,35,3.7500),(26,38,5.2500),(27,3,50.0000),(27,25,25.0000),(27,35,5.0000),(27,38,7.0000),(28,3,66.5000),(28,25,33.2500),(28,35,6.6500),(28,38,9.3100),(29,3,87.5000),(29,25,43.7500),(29,35,8.7500),(29,38,12.2500),(30,3,125.0000),(30,25,62.5000),(30,35,12.5000),(30,38,17.5000),(31,3,26.2500),(31,4,37.5000),(31,26,18.7500),(31,39,5.2500),(32,3,35.0000),(32,4,50.0000),(32,26,25.0000),(32,39,7.0000),(33,3,46.5500),(33,4,66.5000),(33,26,33.2500),(33,39,9.3100),(34,3,61.2500),(34,4,87.5000),(34,26,43.7500),(34,39,12.2500),(35,3,87.5000),(35,4,125.0000),(35,26,62.5000),(35,39,17.5000),(36,10,6.0000),(36,19,3.7500),(36,27,18.7500),(36,32,0.7500),(36,40,5.2500),(37,10,8.0000),(37,19,5.0000),(37,27,25.0000),(37,32,1.0000),(37,40,7.0000),(38,10,10.6400),(38,19,6.6500),(38,27,33.2500),(38,32,1.3300),(38,40,9.3100),(39,10,14.0000),(39,19,8.7500),(39,27,43.7500),(39,32,1.7500),(39,40,12.2500),(40,10,20.0000),(40,19,12.5000),(40,27,62.5000),(40,32,2.5000),(40,40,17.5000),(41,1,150.0000),(41,2,75.0000),(41,3,22.5000),(41,4,22.5000),(41,5,15.0000),(41,6,7.5000),(41,20,3.7500),(41,21,3.7500),(41,22,3.7500),(41,23,3.7500),(41,24,3.7500),(41,29,18.7500),(41,42,3.7500),(41,43,2.2500),(42,1,200.0000),(42,2,100.0000),(42,3,30.0000),(42,4,30.0000),(42,5,20.0000),(42,6,10.0000),(42,20,5.0000),(42,21,5.0000),(42,22,5.0000),(42,23,5.0000),(42,24,5.0000),(42,29,25.0000),(42,42,5.0000),(42,43,3.0000),(43,1,266.0000),(43,2,133.0000),(43,3,39.9000),(43,4,39.9000),(43,5,26.6000),(43,6,13.3000),(43,20,6.6500),(43,21,6.6500),(43,22,6.6500),(43,23,6.6500),(43,24,6.6500),(43,29,33.2500),(43,42,6.6500),(43,43,3.9900),(44,1,350.0000),(44,2,175.0000),(44,3,52.5000),(44,4,52.5000),(44,5,35.0000),(44,6,17.5000),(44,20,8.7500),(44,21,8.7500),(44,22,8.7500),(44,23,8.7500),(44,24,8.7500),(44,29,43.7500),(44,42,8.7500),(44,43,5.2500),(45,1,500.0000),(45,2,250.0000),(45,3,75.0000),(45,4,75.0000),(45,5,50.0000),(45,6,25.0000),(45,20,12.5000),(45,21,12.5000),(45,22,12.5000),(45,23,12.5000),(45,24,12.5000),(45,29,62.5000),(45,42,12.5000),(45,43,7.5000),(46,5,37.5000),(46,6,22.5000),(46,10,3.7500),(46,15,7.5000),(46,16,3.7500),(46,20,3.7500),(46,21,3.7500),(46,22,3.7500),(46,23,3.7500),(46,24,3.7500),(46,28,18.7500),(46,40,3.7500),(46,41,3.7500),(47,5,50.0000),(47,6,30.0000),(47,10,5.0000),(47,15,10.0000),(47,16,5.0000),(47,20,5.0000),(47,21,5.0000),(47,22,5.0000),(47,23,5.0000),(47,24,5.0000),(47,28,25.0000),(47,40,5.0000),(47,41,5.0000),(48,5,66.5000),(48,6,39.9000),(48,10,6.6500),(48,15,13.3000),(48,16,6.6500),(48,20,6.6500),(48,21,6.6500),(48,22,6.6500),(48,23,6.6500),(48,24,6.6500),(48,28,33.2500),(48,40,6.6500),(48,41,6.6500),(49,5,87.5000),(49,6,52.5000),(49,10,8.7500),(49,15,17.5000),(49,16,8.7500),(49,20,8.7500),(49,21,8.7500),(49,22,8.7500),(49,23,8.7500),(49,24,8.7500),(49,28,43.7500),(49,40,8.7500),(49,41,8.7500),(50,5,125.0000),(50,6,75.0000),(50,10,12.5000),(50,15,25.0000),(50,16,12.5000),(50,20,12.5000),(50,21,12.5000),(50,22,12.5000),(50,23,12.5000),(50,24,12.5000),(50,28,62.5000),(50,40,12.5000),(50,41,12.5000);
/*!40000 ALTER TABLE `tmpl_linh_can_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_linh_thao`
--

DROP TABLE IF EXISTS `tmpl_linh_thao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_linh_thao` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ten` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pham_cap` enum('Pham','Linh','Bao','Tien','Than') COLLATE utf8mb4_unicode_ci NOT NULL,
  `he` enum('Kim','Moc','Thuy','Hoa','Tho','Loi','Bang','Phong','Duong','Am') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thoi_gian_sinh_truong` int unsigned NOT NULL,
  `ti_le_dot_pha_bonus` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '% cộng vào tỉ lệ đột phá khi dùng',
  `exp_bonus` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Exp cộng thêm khi dùng',
  `tu_vi_bonus` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Tu vi cộng thêm khi dùng',
  `thoi_gian_hieu_luc` int unsigned NOT NULL DEFAULT '0' COMMENT 'Thời gian hiệu lực (giây)',
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_linh_thao_ten` (`ten`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_linh_thao`
--

LOCK TABLES `tmpl_linh_thao` WRITE;
/*!40000 ALTER TABLE `tmpl_linh_thao` DISABLE KEYS */;
INSERT INTO `tmpl_linh_thao` VALUES (1,'Nhân Sâm','Pham','Moc',300,0.00,0,0,0,'Linh thảo cơ bản, dùng luyện đan hồi phục'),(2,'Linh Chi','Pham','Moc',400,0.00,0,0,0,'Nấm linh chi, dùng luyện đan tu luyện'),(3,'Hà Thủ Ô','Pham','Moc',350,0.00,0,0,0,'Dược liệu bổ máu'),(4,'Đương Quy','Pham','Moc',350,0.00,0,0,0,'Dược liệu bổ khí'),(5,'Câu Kỷ Tử','Pham','Moc',300,0.00,0,0,0,'Quả câu kỷ, tăng tuổi thọ'),(6,'Bạch Truật','Linh','Tho',600,0.50,5,5,600,'Thảo dược linh cấp, hỗ trợ đột phá'),(7,'Tuyết Liên Hoa','Linh','Bang',900,1.00,50,50,900,'Hoa sen tuyết, hiếm gặp, tăng tỉ lệ đột phá'),(8,'Huyết Tinh Thảo','Linh','Hoa',800,0.80,40,40,800,'Cỏ huyết tinh, tăng khí huyết'),(9,'Tử Vân Thảo','Linh','Loi',1000,0.80,50,50,1000,'Cỏ tử vân, luyện đan lôi hệ'),(10,'Ngọc Linh Sâm','Linh','Moc',700,0.60,60,60,700,'Nhân sâm ngọc, quý hiếm, dùng luyện đan'),(11,'Long Tiên Thảo','Bao','Moc',2400,0.00,0,0,2400,'Cỏ long tiên, chữa bách bệnh, luyện đan hồi phục cấp cao'),(12,'Phượng Hoàng Hoa','Bao','Hoa',2400,1.00,200,200,2400,'Hoa phượng hoàng, luyện đan hỏa hệ'),(13,'Huyền Băng Liên','Bao','Bang',2400,2.50,400,400,2400,'Sen băng huyền, luyện đan băng hệ'),(14,'Thiên Niên Nhân Sâm','Bao','Moc',3600,3.00,500,500,3600,'Nhân sâm ngàn năm, cực quý, luyện đan tu luyện'),(15,'Long Huyết Thảo','Tien','Hoa',7200,5.00,1000,1000,7200,'Cỏ long huyết, tăng sinh lực'),(16,'Phượng Vũ Hoa','Tien','Hoa',7200,5.00,1000,1000,7200,'Hoa lông phượng, cực phẩm'),(17,'Cửu Diệp Liên','Tien','Thuy',7200,5.00,1000,1000,7200,'Sen chín lá, luyện đan thủy hệ'),(18,'Tử Kim Đằng','Tien','Loi',7200,5.00,1000,1000,7200,'Dây tử kim, luyện đan lôi hệ'),(19,'Hỗn Độn Thảo','Than',NULL,14400,10.00,5000,5000,14400,'Cỏ hỗn độn, truyền thuyết'),(20,'Nghịch Thiên Thảo','Than',NULL,14400,10.00,5000,5000,14400,'Cỏ nghịch thiên, đổi vận mệnh');
/*!40000 ALTER TABLE `tmpl_linh_thao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_nghe_nghiep`
--

DROP TABLE IF EXISTS `tmpl_nghe_nghiep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_nghe_nghiep` (
  `id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `ten` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loai` enum('LuyenDan','LuyenKhi','TranPhap','PhuLuc') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cap_toi_da` tinyint unsigned NOT NULL,
  `exp_moi_cap` json NOT NULL,
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_nghe_nghiep_ten` (`ten`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_nghe_nghiep`
--

LOCK TABLES `tmpl_nghe_nghiep` WRITE;
/*!40000 ALTER TABLE `tmpl_nghe_nghiep` DISABLE KEYS */;
INSERT INTO `tmpl_nghe_nghiep` VALUES (1,'Luyện Đan Sư','LuyenDan',9,'{\"1\": 100, \"2\": 300, \"3\": 800, \"4\": 2000, \"5\": 5000, \"6\": 12000, \"7\": 30000, \"8\": 80000, \"9\": 200000}','Chế tạo đan dược từ linh thảo'),(2,'Luyện Khí Sư','LuyenKhi',9,'{\"1\": 100, \"2\": 300, \"3\": 800, \"4\": 2000, \"5\": 5000, \"6\": 12000, \"7\": 30000, \"8\": 80000, \"9\": 200000}','Rèn đúc pháp bảo, linh khí'),(3,'Trận Pháp Sư','TranPhap',9,'{\"1\": 150, \"2\": 400, \"3\": 1000, \"4\": 2500, \"5\": 6000, \"6\": 15000, \"7\": 40000, \"8\": 100000, \"9\": 250000}','Bày trận pháp, mượn lực của đất trời'),(4,'Phù Lục Sư','PhuLuc',9,'{\"1\": 100, \"2\": 300, \"3\": 800, \"4\": 2000, \"5\": 5000, \"6\": 12000, \"7\": 30000, \"8\": 80000, \"9\": 200000}','Vẽ phù lục, bùa chú cường hóa');
/*!40000 ALTER TABLE `tmpl_nghe_nghiep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_nghe_nghiep_bonus`
--

DROP TABLE IF EXISTS `tmpl_nghe_nghiep_bonus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_nghe_nghiep_bonus` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nghe_nghiep_id` tinyint unsigned NOT NULL,
  `stat_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gia_tri_bonus` decimal(10,4) NOT NULL,
  `mo_ta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_nghe_stat` (`nghe_nghiep_id`,`stat_code`),
  CONSTRAINT `fk_nnb_nghe` FOREIGN KEY (`nghe_nghiep_id`) REFERENCES `tmpl_nghe_nghiep` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bonus stat cho từng nghề nghiệp';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_nghe_nghiep_bonus`
--

LOCK TABLES `tmpl_nghe_nghiep_bonus` WRITE;
/*!40000 ALTER TABLE `tmpl_nghe_nghiep_bonus` DISABLE KEYS */;
INSERT INTO `tmpl_nghe_nghiep_bonus` VALUES (1,1,'bonus_linh_thao_lichluyen',30.0000,'Tỉ lệ gặp linh thảo khi lịch luyện +30%'),(2,1,'bonus_tu_luyen_hoa',20.0000,'Hiệu suất tu luyện công pháp Hỏa hệ +20%'),(3,1,'bonus_tu_luyen_moc',20.0000,'Hiệu suất tu luyện công pháp Mộc hệ +20%'),(4,1,'bonus_hieu_qua_buff_dan_duoc',20.0000,'Hiệu quả tích cực khi dùng đan dược +20%'),(5,1,'bonus_luyen_dan_thanh_cong',5.0000,'Tỉ lệ thành công luyện đan +5%'),(6,2,'bonus_linh_thach_lichluyen',30.0000,'Lượng linh thạch nhận khi lịch luyện +30%'),(7,2,'bonus_khoang_thach_lichluyen',30.0000,'Tỉ lệ gặp khoáng thạch khi lịch luyện +30%'),(8,2,'bonus_tu_luyen_kim',20.0000,'Hiệu suất tu luyện công pháp Kim hệ +20%'),(9,2,'bonus_tu_luyen_tho',20.0000,'Hiệu suất tu luyện công pháp Thổ hệ +20%'),(10,2,'bonus_luyen_khi_thanh_cong',5.0000,'Tỉ lệ thành công luyện khí +5%'),(11,3,'bonus_dao_cu_drop',20.0000,'Tỉ lệ rớt đạo cụ +20%'),(12,3,'bonus_tu_luyen_thuy',20.0000,'Hiệu suất tu luyện công pháp Thủy hệ +20%'),(13,3,'bonus_tu_luyen_phong',20.0000,'Hiệu suất tu luyện công pháp Phong hệ +20%'),(14,3,'bonus_tu_luyen_duong',20.0000,'Hiệu suất tu luyện công pháp Dương hệ +20%'),(15,3,'bonus_tu_luyen_am',20.0000,'Hiệu suất tu luyện công pháp Âm hệ +20%'),(16,3,'bonus_tran_phap_thanh_cong',10.0000,'Tỉ lệ thành công bày trận +10%'),(17,4,'bonus_linh_thach_lichluyen',20.0000,'Tỉ lệ gặp linh thạch khi lịch luyện +20%'),(18,4,'bonus_tu_luyen_hoa',5.0000,'Hiệu suất tu luyện công pháp Hỏa hệ +5%'),(19,4,'bonus_tu_luyen_tho',5.0000,'Hiệu suất tu luyện công pháp Thổ hệ +5%'),(20,4,'bonus_tu_luyen_kim',5.0000,'Hiệu suất tu luyện công pháp Kim hệ +5%'),(21,4,'bonus_tu_luyen_thuy',5.0000,'Hiệu suất tu luyện công pháp Thủy hệ +5%'),(22,4,'bonus_tu_luyen_moc',5.0000,'Hiệu suất tu luyện công pháp Mộc hệ +5%'),(23,4,'bonus_tu_luyen_phong',5.0000,'Hiệu suất tu luyện công pháp Phong hệ +5%'),(24,4,'bonus_tu_luyen_loi',5.0000,'Hiệu suất tu luyện công pháp Lôi hệ +5%'),(25,4,'bonus_tu_luyen_duong',5.0000,'Hiệu suất tu luyện công pháp Dương hệ +5%'),(26,4,'bonus_tu_luyen_am',5.0000,'Hiệu suất tu luyện công pháp Âm hệ +5%'),(27,4,'bonus_tu_luyen_bang',5.0000,'Hiệu suất tu luyện công pháp Băng hệ +5%'),(28,4,'bonus_phu_luc_thanh_cong',10.0000,'Tỉ lệ thành công vẽ phù lục +10%');
/*!40000 ALTER TABLE `tmpl_nghe_nghiep_bonus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_shop_item`
--

DROP TABLE IF EXISTS `tmpl_shop_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_shop_item` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `item_type` enum('DanDuoc','DaoCu','LinhThao','KhoangThach','CongPhap') COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` int unsigned NOT NULL COMMENT 'ID tham chiếu tới bảng tương ứng',
  `gia_linh_thach` int unsigned NOT NULL DEFAULT '0',
  `gia_tien_ngoc` int unsigned NOT NULL DEFAULT '0',
  `so_luong_ton` int unsigned NOT NULL DEFAULT '0' COMMENT '0 = hết hàng, > 0 = còn hàng',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `thu_tu_hien_thi` smallint unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_shop_item` (`item_type`,`item_id`),
  KEY `idx_shop_type` (`item_type`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_shop_item`
--

LOCK TABLES `tmpl_shop_item` WRITE;
/*!40000 ALTER TABLE `tmpl_shop_item` DISABLE KEYS */;
INSERT INTO `tmpl_shop_item` VALUES (1,'DanDuoc',1,100,0,100,1,1),(2,'DanDuoc',2,80,0,100,1,2),(3,'DanDuoc',3,1199,0,100,1,3),(4,'DanDuoc',4,799,0,100,1,4),(5,'DanDuoc',5,1199,0,100,1,5),(6,'DanDuoc',6,9999,0,100,1,6),(7,'DanDuoc',7,6999,0,100,1,7),(8,'DanDuoc',8,199999,0,100,1,8),(9,'DanDuoc',9,150,0,98,1,9),(10,'DanDuoc',10,1999,0,100,1,10),(11,'DanDuoc',11,999,0,100,1,11),(12,'DanDuoc',12,4999,0,100,1,12),(13,'DanDuoc',13,39999,0,100,1,13),(14,'DanDuoc',14,3999,0,100,1,14),(15,'DanDuoc',34,399,0,100,1,15),(16,'DanDuoc',35,1399,0,100,1,16),(17,'DanDuoc',36,9999,0,100,1,17),(18,'DanDuoc',37,49999,0,100,1,18),(19,'DanDuoc',38,799999,0,100,1,19),(20,'DanDuoc',39,2999999,0,100,1,20),(21,'DanDuoc',40,9999999,0,100,1,21),(22,'DanDuoc',41,39999999,0,100,1,22),(23,'DanDuoc',42,2999,0,100,1,23),(24,'DanDuoc',43,2499,0,100,1,24),(25,'DanDuoc',44,999,0,100,1,25),(26,'DanDuoc',45,4999,0,100,1,26),(27,'DanDuoc',46,1999,0,100,1,27),(28,'DanDuoc',47,6999,0,100,1,28),(29,'DanDuoc',48,1999,0,100,1,29),(30,'DanDuoc',49,6999,0,100,1,30),(31,'DanDuoc',50,2499,0,100,1,31),(32,'DanDuoc',51,7999,0,100,1,32),(33,'DanDuoc',52,1999,0,100,1,33),(34,'DanDuoc',53,6999,0,100,1,34),(35,'DanDuoc',54,2499,0,100,1,35),(36,'DanDuoc',55,7999,0,100,1,36),(37,'DanDuoc',56,1999,0,100,1,37),(38,'DanDuoc',57,6999,0,100,1,38),(39,'DanDuoc',58,4999,0,100,1,39),(40,'DanDuoc',59,4999,0,100,1,40),(41,'DanDuoc',60,5999,0,100,1,41),(42,'DanDuoc',61,9999,0,100,1,42),(43,'DanDuoc',62,14999,0,100,1,43),(44,'DanDuoc',63,39999,0,100,1,44),(45,'DanDuoc',64,5999,0,100,1,45),(46,'DanDuoc',65,5999,0,100,1,46),(47,'DanDuoc',66,12999,0,100,1,47),(48,'DanDuoc',15,4999,0,100,1,50),(49,'DanDuoc',16,39999,4,10,1,51),(50,'DanDuoc',17,7999,0,100,1,52),(51,'DanDuoc',18,59999,6,100,1,53),(52,'DanDuoc',19,9999,0,100,1,54),(53,'DanDuoc',20,99999,10,10,1,55),(54,'DanDuoc',21,12999,0,100,1,56),(55,'DanDuoc',22,159999,16,10,1,57),(56,'DanDuoc',23,14999,0,100,1,58),(57,'DanDuoc',24,299999,30,10,1,59),(58,'DanDuoc',25,19999,0,100,1,60),(59,'DanDuoc',26,679999,69,10,1,61),(60,'DanDuoc',27,24999,0,100,1,62),(61,'DanDuoc',28,1599999,169,10,1,63),(62,'DanDuoc',29,29999,0,100,1,64),(63,'DanDuoc',30,5999999,666,10,1,65),(64,'DanDuoc',31,79999,0,100,1,66),(65,'DanDuoc',32,29999999,3333,10,1,67),(66,'DanDuoc',33,0,100,100,1,68),(71,'DaoCu',13,0,399,50,1,110),(72,'DaoCu',14,0,149,50,1,111),(73,'DaoCu',15,0,149,50,1,112),(74,'DaoCu',16,0,149,50,1,113),(75,'DaoCu',17,0,149,50,1,114),(76,'DaoCu',18,0,299,50,1,120),(77,'DaoCu',19,0,299,50,1,121),(78,'DaoCu',20,0,299,50,1,122),(79,'DaoCu',21,0,499,50,1,130),(80,'DaoCu',22,0,499,50,1,131),(81,'KhoangThach',1,75,0,150,1,201),(82,'KhoangThach',2,300,0,150,1,202),(83,'KhoangThach',3,1200,0,150,1,203),(84,'KhoangThach',4,4500,0,150,1,204),(85,'KhoangThach',5,15000,0,150,1,205),(86,'KhoangThach',6,120,0,150,1,210),(87,'KhoangThach',7,450,0,150,1,211),(88,'KhoangThach',8,1800,0,150,1,212),(89,'KhoangThach',9,12000,0,150,1,213),(90,'KhoangThach',10,75000,0,150,1,214),(91,'KhoangThach',11,90,0,150,1,220),(92,'KhoangThach',12,375,0,150,1,221),(93,'KhoangThach',13,1500,0,150,1,222),(94,'KhoangThach',14,7500,0,150,1,223),(95,'KhoangThach',15,30000,0,150,1,224),(96,'KhoangThach',16,375,0,150,1,230),(97,'KhoangThach',17,375,0,150,1,231),(98,'KhoangThach',18,375,0,150,1,232),(99,'KhoangThach',19,375,0,150,1,233),(100,'KhoangThach',20,375,0,150,1,234),(101,'LinhThao',1,200,0,200,1,301),(102,'LinhThao',2,200,0,200,1,302),(103,'LinhThao',3,200,0,200,1,303),(104,'LinhThao',4,200,0,200,1,304),(105,'LinhThao',5,200,0,200,1,305),(106,'LinhThao',6,2000,0,200,1,310),(107,'LinhThao',7,2000,0,200,1,311),(108,'LinhThao',8,2000,0,200,1,312),(109,'LinhThao',9,2000,0,200,1,313),(110,'LinhThao',10,2000,0,200,1,314),(111,'LinhThao',11,20000,0,200,1,320),(112,'LinhThao',12,20000,0,200,1,321),(113,'LinhThao',13,20000,0,200,1,322),(114,'LinhThao',14,20000,0,200,1,323),(115,'CongPhap',1,5000,0,10,1,401),(116,'CongPhap',2,20000,0,10,1,402),(117,'CongPhap',3,100000,0,10,0,403),(118,'CongPhap',4,500000,0,10,0,404),(119,'CongPhap',5,5000,0,7,1,411),(120,'CongPhap',6,20000,0,10,1,412),(121,'CongPhap',7,100000,0,10,0,413),(122,'CongPhap',8,500000,0,10,0,414),(123,'CongPhap',9,5000,0,10,1,421),(124,'CongPhap',10,20000,0,10,1,422),(125,'CongPhap',11,100000,0,10,0,423),(126,'CongPhap',12,500000,0,10,0,424),(127,'CongPhap',13,5000,0,10,1,431),(128,'CongPhap',14,20000,0,10,1,432),(129,'CongPhap',15,100000,0,10,0,433),(130,'CongPhap',16,500000,0,10,0,434),(131,'CongPhap',17,5000,0,10,1,441),(132,'CongPhap',18,20000,0,10,1,442),(133,'CongPhap',19,100000,0,10,0,443),(134,'CongPhap',20,500000,0,10,0,444),(135,'CongPhap',21,5000,0,10,1,451),(136,'CongPhap',22,20000,0,10,1,452),(137,'CongPhap',23,100000,0,10,0,453),(138,'CongPhap',24,500000,0,10,0,454),(139,'CongPhap',25,5000,0,10,1,461),(140,'CongPhap',26,20000,0,10,1,462),(141,'CongPhap',27,100000,0,10,0,463),(142,'CongPhap',28,500000,0,10,0,464),(143,'CongPhap',29,5000,0,10,1,471),(144,'CongPhap',30,20000,0,10,1,472),(145,'CongPhap',31,100000,0,10,0,473),(146,'CongPhap',32,500000,0,10,0,474),(147,'CongPhap',33,5000,0,10,1,481),(148,'CongPhap',34,20000,0,10,1,482),(149,'CongPhap',35,100000,0,10,0,483),(150,'CongPhap',36,500000,0,10,0,484),(151,'CongPhap',37,5000,0,10,1,491),(152,'CongPhap',38,20000,0,10,1,492),(153,'CongPhap',39,100000,0,10,0,493),(154,'CongPhap',40,500000,0,10,0,494),(164,'DaoCu',23,0,10,100,1,501),(165,'DaoCu',24,0,99,100,1,502),(166,'DaoCu',25,0,199,100,1,503),(167,'DaoCu',26,0,299,100,1,504),(168,'DaoCu',27,50000,0,100,1,510),(169,'DaoCu',28,300000,0,100,1,511),(170,'DaoCu',29,2000000,0,100,1,512),(171,'DaoCu',30,9000000,0,100,1,513),(172,'DaoCu',31,0,0,0,1,514);
/*!40000 ALTER TABLE `tmpl_shop_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_stat_khoi_dau`
--

DROP TABLE IF EXISTS `tmpl_stat_khoi_dau`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_stat_khoi_dau` (
  `stat_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gia_tri` int unsigned NOT NULL,
  `mo_ta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`stat_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stat khởi đầu của mọi nhân vật (trước khi cộng bonus)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_stat_khoi_dau`
--

LOCK TABLES `tmpl_stat_khoi_dau` WRITE;
/*!40000 ALTER TABLE `tmpl_stat_khoi_dau` DISABLE KEYS */;
INSERT INTO `tmpl_stat_khoi_dau` VALUES ('atk',10,'Công kích khởi đầu'),('def',5,'Phòng ngự khởi đầu'),('hp_max',100,'HP tối đa khởi đầu'),('matk',8,'Công kích phép khởi đầu'),('mdef',5,'Phòng ngự phép khởi đầu'),('mp_max',50,'MP tối đa khởi đầu');
/*!40000 ALTER TABLE `tmpl_stat_khoi_dau` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpl_stat_type`
--

DROP TABLE IF EXISTS `tmpl_stat_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmpl_stat_type` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten_hien_thi` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nhom` enum('CoBan','ChienDau','KhangNguyenTo','TuLuyen','Utility','HieuUng','HoiPhuc') COLLATE utf8mb4_unicode_ci NOT NULL,
  `don_vi` enum('flat','percent','multiplier') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'flat',
  `gia_tri_mac_dinh` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `gia_tri_toi_da` decimal(10,4) DEFAULT NULL,
  `gia_tri_toi_thieu` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `cong_thuc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mo_ta` text COLLATE utf8mb4_unicode_ci,
  `thu_tu_hien_thi` smallint unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_stat_code` (`code`),
  KEY `idx_nhom` (`nhom`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Định nghĩa metadata các loại stat. code dùng trong bot.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpl_stat_type`
--

LOCK TABLES `tmpl_stat_type` WRITE;
/*!40000 ALTER TABLE `tmpl_stat_type` DISABLE KEYS */;
INSERT INTO `tmpl_stat_type` VALUES (1,'hp_max','Máu tối đa','CoBan','flat',100.0000,NULL,0.0000,NULL,'Lượng máu tối đa của nhân vật',1),(2,'mp_max','Linh lực tối đa','CoBan','flat',50.0000,NULL,0.0000,NULL,'Lượng linh lực tối đa',2),(3,'atk','Công kích','CoBan','flat',10.0000,NULL,0.0000,NULL,'Sát thương vật lý cơ bản',3),(4,'def','Phòng ngự','CoBan','flat',5.0000,NULL,0.0000,NULL,'Giảm sát thương vật lý nhận vào',4),(5,'matk','Công kích phép','CoBan','flat',8.0000,NULL,0.0000,NULL,'Sát thương phép cơ bản',5),(6,'mdef','Phòng ngự phép','CoBan','flat',5.0000,NULL,0.0000,NULL,'Giảm sát thương phép nhận vào',6),(7,'hp_max_pct','Máu tối đa %','CoBan','percent',0.0000,500.0000,0.0000,NULL,'Tăng % máu tối đa',7),(8,'mp_max_pct','Linh lực tối đa %','CoBan','percent',0.0000,500.0000,0.0000,NULL,'Tăng % linh lực tối đa',8),(9,'ti_le_chinh_xac','Tỉ lệ chính xác','ChienDau','percent',100.0000,100.0000,0.0000,NULL,'Xác suất đánh trúng đối thủ (%)',9),(10,'ti_le_ne','Tỉ lệ né','ChienDau','percent',0.0000,75.0000,0.0000,NULL,'Xác suất né đòn tấn công',10),(11,'ti_le_chi_mang','Tỉ lệ chí mạng','ChienDau','percent',5.0000,100.0000,0.0000,NULL,'Xác suất gây chí mạng',11),(12,'sat_thuong_chi_mang','Sát thương chí mạng','ChienDau','percent',150.0000,500.0000,100.0000,NULL,'Hệ số sát thương khi chí mạng (%)',12),(13,'ti_le_khang_chi_mang','Kháng chí mạng','ChienDau','percent',0.0000,90.0000,0.0000,NULL,'Giảm xác suất bị chí mạng',13),(14,'ti_le_xuyen_giap','Xuyên giáp vật lý','ChienDau','percent',0.0000,90.0000,0.0000,NULL,'Bỏ qua % phòng ngự vật lý của đối thủ',14),(15,'ti_le_xuyen_phep','Xuyên giáp phép','ChienDau','percent',0.0000,90.0000,0.0000,NULL,'Bỏ qua % phòng ngự phép của đối thủ',15),(16,'ti_le_hut_mau','Hút máu','ChienDau','percent',0.0000,50.0000,0.0000,NULL,'Hồi % sát thương gây ra thành HP',16),(17,'ti_le_hoi_mp','Hồi linh lực','ChienDau','percent',0.0000,50.0000,0.0000,NULL,'Hồi MP theo lượt',17),(18,'giam_sat_thuong_nhan','Giảm sát thương nhận','ChienDau','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương nhận từ mọi nguồn',18),(19,'giam_hoi_chieu','Giảm hồi chiêu','ChienDau','percent',0.0000,45.0000,0.0000,NULL,'Giảm % thời gian hồi chiêu của các action và skill. Tối đa 45%',19),(20,'khang_kim','Kháng Kim','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Kim nhận vào',20),(21,'khang_moc','Kháng Mộc','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Mộc nhận vào',21),(22,'khang_thuy','Kháng Thủy','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Thủy nhận vào',22),(23,'khang_hoa','Kháng Hỏa','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Hỏa nhận vào',23),(24,'khang_tho','Kháng Thổ','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Thổ nhận vào',24),(25,'khang_loi','Kháng Lôi','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Lôi nhận vào',25),(26,'khang_bang','Kháng Băng','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Băng nhận vào',26),(27,'khang_phong','Kháng Phong','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Phong nhận vào',27),(28,'khang_duong','Kháng Dương','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Dương nhận vào',28),(29,'khang_am','Kháng Âm','KhangNguyenTo','percent',0.0000,90.0000,0.0000,NULL,'Giảm % sát thương hệ Âm nhận vào',29),(30,'toc_do_tu_luyen','Tốc độ tu luyện','TuLuyen','percent',100.0000,1000.0000,1.0000,NULL,'Hệ số nhân exp nhận được khi tu luyện (%)',30),(31,'bonus_ti_le_dot_pha','Bonus tỉ lệ đột phá','TuLuyen','percent',0.0000,100.0000,0.0000,NULL,'% cộng vào tỉ lệ đột phá',31),(32,'ti_le_ngo_dao','Tỉ lệ ngộ đạo','TuLuyen','percent',0.0000,20.0000,0.0000,NULL,'Xác suất nhận bonus tu vi ngẫu nhiên',32),(33,'tam_canh_bonus','Bonus tâm cảnh','TuLuyen','percent',0.0000,10.0000,0.0000,NULL,'Bonus tỉ lệ đột phá từ tâm cảnh',33),(34,'khi_van_bonus','Bonus khí vận','TuLuyen','percent',0.0000,10.0000,0.0000,NULL,'Bonus tỉ lệ đột phá từ khí vận',34),(35,'ti_le_thanh_cong_do_kiep','Tỉ lệ độ kiếp thành công','TuLuyen','percent',0.0000,95.0000,0.0000,NULL,'% tỉ lệ độ kiếp thành công',35),(36,'ti_le_gay_bong','Tỉ lệ gây bỏng','HieuUng','percent',0.0000,70.0000,0.0000,NULL,'Xác suất gây hiệu ứng bỏng',40),(37,'sat_thuong_bong_moi_luot','Sát thương bỏng/lượt','HieuUng','flat',0.0000,NULL,0.0000,NULL,'Sát thương mỗi lượt khi bị bỏng',41),(38,'ti_le_gay_te_liet','Tỉ lệ gây tê liệt','HieuUng','percent',0.0000,70.0000,0.0000,NULL,'Xác suất gây tê liệt (mất lượt)',42),(39,'ti_le_gay_dong_bang','Tỉ lệ gây đóng băng','HieuUng','percent',0.0000,70.0000,0.0000,NULL,'Xác suất gây đóng băng (không hành động)',43),(40,'ti_le_gay_mu','Tỉ lệ gây mù','HieuUng','percent',0.0000,70.0000,0.0000,NULL,'Xác suất gây mù (giảm chính xác)',44),(41,'ti_le_gay_roi_loan','Tỉ lệ gây rối loạn','HieuUng','percent',0.0000,70.0000,0.0000,NULL,'Xác suất gây rối loạn (đánh nhầm)',45),(42,'ti_le_kich_hoat_hoi_hp','Tỉ lệ kích hoạt hồi HP','HoiPhuc','percent',0.0000,100.0000,0.0000,NULL,'Xác suất kích hoạt hồi HP mỗi lượt',49),(43,'phan_tram_hoi_hp_moi_luot','% HP hồi mỗi lượt','HoiPhuc','percent',5.0000,25.0000,0.0000,NULL,'% HP_max hồi mỗi lượt khi kích hoạt',50),(44,'hieu_ung_hoi_phuc_bonus','Bonus hiệu ứng hồi phục','HoiPhuc','percent',0.0000,500.0000,0.0000,NULL,'Bonus % nhân vào lượng hồi phục',51),(45,'bonus_ti_le_roi_do','Bonus tỉ lệ rớt đồ','Utility','percent',0.0000,500.0000,0.0000,NULL,'Bonus % tỉ lệ rớt đồ',59),(46,'bonus_ti_le_roi_linh_thach','Bonus tỉ lệ rớt linh thạch','Utility','percent',0.0000,500.0000,0.0000,NULL,'Bonus % tỉ lệ rớt linh thạch',60),(47,'atk_pct','Công kích %','CoBan','percent',0.0000,500.0000,0.0000,NULL,'Tăng % công kích',70),(48,'def_pct','Phòng ngự %','CoBan','percent',0.0000,500.0000,0.0000,NULL,'Tăng % phòng ngự',71),(49,'matk_pct','Công kích phép %','CoBan','percent',0.0000,500.0000,0.0000,NULL,'Tăng % công kích phép',72),(50,'mdef_pct','Phòng ngự phép %','CoBan','percent',0.0000,500.0000,0.0000,NULL,'Tăng % phòng ngự phép',73);
/*!40000 ALTER TABLE `tmpl_stat_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-16 11:32:28
